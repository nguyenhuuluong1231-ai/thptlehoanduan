// Nhóm luồng worker nhỏ để chạy Argon2id song song, không chặn vòng lặp sự kiện chính của máy chủ.
import { Worker } from 'node:worker_threads';
import { fileURLToPath } from 'node:url';
import path from 'node:path';

const WORKER_FILE = path.join(path.dirname(fileURLToPath(import.meta.url)), 'argon2-worker.js');

export function createArgon2Pool(size = 2) {
  const workers = Array.from({ length: Math.max(1, size) }, () => new Worker(WORKER_FILE));
  const pending = new Map();
  let seq = 0, next = 0;
  // Worker nhàn rỗi không giữ tiến trình sống (unref) — nhưng PHẢI ref lại ngay khi có việc đang
  // chờ kết quả, kể cả lúc khởi động trước khi server.listen() tạo handle giữ event loop: nếu không,
  // Node có thể thoát tiến trình giữa lúc đang băm mật khẩu (Promise không bao giờ resolve) vì
  // unref() khiến worker không được tính là "đang hoạt động" dù đang xử lý yêu cầu.
  for (const w of workers) {
    w.on('message', (msg) => {
      const p = pending.get(msg.id); if (!p) return;
      pending.delete(msg.id);
      if (pending.size === 0) for (const ww of workers) ww.unref();
      if (msg.error) p.reject(new Error(msg.error)); else p.resolve(new Uint8Array(msg.hash));
    });
    w.on('error', (e) => { for (const [id, p] of pending) { p.reject(e); pending.delete(id); } if (pending.size === 0) for (const ww of workers) ww.unref(); });
    w.unref();
  }
  return {
    run({ password, salt, t, m, p, tagLength }) {
      return new Promise((resolve, reject) => {
        const id = ++seq;
        pending.set(id, { resolve, reject });
        for (const ww of workers) ww.ref(); // có việc đang chờ: giữ tiến trình sống tới khi xong
        const w = workers[next]; next = (next + 1) % workers.length;
        w.postMessage({ id, password: password.buffer.slice(password.byteOffset, password.byteOffset + password.byteLength), salt: salt.buffer.slice(salt.byteOffset, salt.byteOffset + salt.byteLength), t, m, p, tagLength });
      });
    },
    async close() { await Promise.all(workers.map(w => w.terminate())); },
  };
}
