// Danh sách Tổ tâm lý học đường (thành viên, lịch trực, lĩnh vực hỗ trợ).
// Thành viên có tài khoản giáo viên (userId) thì học sinh nhắn tin trực tiếp được trong mục “Chat với giáo viên”.
export const TEAM_ROLES = ['Tổ trưởng', 'Chuyên viên tâm lý', 'Giáo viên kiêm nhiệm', 'Nhân viên y tế', 'Cộng tác viên'];

export function defaultCounselTeam(users = []) {
  const has = (id) => users.some(u => u.id === id);
  const t = new Date().toISOString();
  return [
    { id: 'TL1', name: 'ThS. Nguyễn An Bình', role: 'Tổ trưởng', title: 'Chuyên viên Tâm lý học đường', userId: has('GV2024012') ? 'GV2024012' : '', phone: '0912 888 999', email: 'binh.na@lehoan.edu.vn', room: 'Phòng Tham vấn · Tầng 1 dãy B', days: [1, 2, 3, 4, 5, 6], hours: '07:00-11:00', topics: ['Áp lực học tập', 'Định hướng nghề nghiệp', 'Khủng hoảng tâm lý'], bio: 'Hơn 10 năm tham vấn học đường. Luôn sẵn sàng lắng nghe, mọi chia sẻ đều được giữ bí mật.', avatar: null, order: 1, active: true, updatedAt: t },
    { id: 'TL2', name: 'Cô Trần Mai Phương', role: 'Giáo viên kiêm nhiệm', title: 'Giáo viên GDCD · Tư vấn học đường', userId: '', phone: '', email: 'phuong.tm@lehoan.edu.vn', room: 'Phòng Tham vấn · Tầng 1 dãy B', days: [2, 4], hours: '14:00-16:30', topics: ['Quan hệ bạn bè', 'Gia đình', 'Giới tính & tuổi dậy thì'], bio: 'Đồng hành cùng các em trong những câu chuyện về bạn bè, gia đình và tuổi mới lớn.', avatar: null, order: 2, active: true, updatedAt: t },
    { id: 'TL3', name: 'Thầy Phan Minh Tuấn', role: 'Giáo viên kiêm nhiệm', title: 'Phó Bí thư Đoàn trường · Kỹ năng sống', userId: '', phone: '', email: 'tuan.pm@lehoan.edu.vn', room: 'Văn phòng Đoàn · Tầng 2 dãy A', days: [3, 6], hours: '07:30-10:30', topics: ['Bắt nạt học đường', 'An toàn mạng xã hội', 'Kỹ năng sống'], bio: 'Hỗ trợ các em xử lý bắt nạt, rắc rối trên mạng xã hội và rèn kỹ năng ứng phó.', avatar: null, order: 3, active: true, updatedAt: t },
    { id: 'TL4', name: 'Cô Lê Hoàng Yến', role: 'Nhân viên y tế', title: 'Y tế học đường', userId: '', phone: '', email: 'yen.lh@lehoan.edu.vn', room: 'Phòng Y tế · Tầng 1 dãy C', days: [1, 2, 3, 4, 5, 6], hours: '07:00-17:00', topics: ['Sức khỏe thể chất', 'Giấc ngủ', 'Căng thẳng mùa thi'], bio: 'Chăm sóc sức khỏe, hướng dẫn thư giãn và phối hợp với chuyên viên tâm lý khi cần.', avatar: null, order: 4, active: true, updatedAt: t },
    { id: 'TL5', name: 'ThS. Đỗ Thu Trang', role: 'Cộng tác viên', title: 'Chuyên gia tham vấn · Trung tâm Tham vấn tâm lý tỉnh', userId: '', phone: '', email: '', room: 'Phòng Tham vấn · Tầng 1 dãy B', days: [5], hours: '08:00-11:00', topics: ['Lo âu', 'Trầm cảm', 'Tham vấn chuyên sâu'], bio: 'Tham vấn chuyên sâu định kỳ tại trường. Đặt lịch qua chuyên viên tâm lý của trường.', avatar: null, order: 5, active: true, updatedAt: t },
  ];
}
