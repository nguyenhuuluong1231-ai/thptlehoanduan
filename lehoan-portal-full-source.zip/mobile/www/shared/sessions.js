// Theo dõi phiên đăng nhập phía máy chủ.
// Mỗi token mang một mã phiên (jti) duy nhất. Mã này đổi sang giá trị MỚI sau mỗi ROTATE_SEC giây
// sử dụng — chuỗi token cũ bị thu hồi ngay khi token mới được phát ra — nên nếu một token bị lộ
// (chặn được qua mạng, lưu lại trong log…), nó chỉ còn dùng được trong một khoảng thời gian ngắn
// trước khi bị vô hiệu bởi lượt đổi token tiếp theo của chính người dùng thật, hạn chế việc phát lại / dò (spam).
// Phiên cũng tự hết hạn nếu không hoạt động quá IDLE_SEC, và không bao giờ vượt quá hạn tuyệt đối (abs)
// được quyết định khi đăng nhập (ghi nhớ đăng nhập: 30 ngày, không ghi nhớ: 1 ngày).
export const ROTATE_SEC = 60;
export const IDLE_SEC = 30 * 60;

// Bộ nhớ trong tiến trình: khi khởi động lại máy chủ, toàn bộ phiên bị xóa (buộc đăng nhập lại) —
// đây là lựa chọn an toàn hơn lưu phiên xuống đĩa.
const sessions = new Map(); // jti -> { userId, v, abs, issuedAt, lastSeen, device }

export function putSession(jti, info) {
  sessions.set(jti, { ...info, issuedAt: info.issuedAt ?? Date.now() / 1000, lastSeen: Date.now() / 1000 });
}
export function getSession(jti) { return sessions.get(jti) || null; }
export function touchSession(jti) { const s = sessions.get(jti); if (s) s.lastSeen = Date.now() / 1000; return s; }
export function dropSession(jti) { sessions.delete(jti); }
export function dropAllForUser(userId) { for (const [id, s] of sessions) if (s.userId === userId) sessions.delete(id); }
export function listForUser(userId) {
  return [...sessions.entries()].filter(([, s]) => s.userId === userId).sort((a, b) => b[1].lastSeen - a[1].lastSeen).map(([jti, s]) => ({ jti, device: s.device || '', issuedAt: s.issuedAt, lastSeen: s.lastSeen, current: false }));
}
export function sessionValid(s) {
  if (!s) return false;
  const now = Date.now() / 1000;
  return now <= s.abs && now - s.lastSeen <= IDLE_SEC;
}
export function needsRotation(s) { return Date.now() / 1000 - s.issuedAt >= ROTATE_SEC; }

// Dùng cho bản xem trước/demo trong trình duyệt (client-src/js/core/demo.js): mỗi lần chuyển trang
// (vd. trang đăng nhập → app.html) là một lần nạp lại toàn bộ trang, nên bộ nhớ "sessions" ở trên bị
// xoá sạch — phải lưu/khôi phục qua localStorage để phiên đăng nhập không bị mất ngay khi chuyển trang.
// Máy chủ Node.js thật (server.js) không bao giờ gọi hai hàm này nên hành vi của nó không đổi.
export function snapshotSessions() { return [...sessions.entries()]; }
export function restoreSessions(entries) { if (Array.isArray(entries)) for (const [jti, info] of entries) if (jti && info) sessions.set(jti, info); }
