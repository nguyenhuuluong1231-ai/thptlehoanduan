// Nâng cấp dữ liệu cũ (data/db.json hoặc dữ liệu bản xem trước trong trình duyệt) khi cập nhật phiên bản mới.
// An toàn khi chạy nhiều lần.
import { defaultCounselTeam } from './counsel-team.js';

const TEXT_FIXES = [
  [/Dự án Nghiên cứu Khoa học Kỹ thuật của học sinh THPT Lê Hoàn\./g, 'Đề tài nghiên cứu của học sinh THPT Lê Hoàn.'],
  [/([Kk])hảo sát KH-KT/g, '$1hảo sát'],
  [/Nghiên cứu KH-KT/g, 'Nghiên cứu khoa học'],
  [/đề tài KH-KT/g, 'đề tài nghiên cứu'],
];
const fixText = (v) => (typeof v === 'string' ? TEXT_FIXES.reduce((s, [re, to]) => s.replace(re, to), v) : v);

export function migrateData(d) {
  if (!d || typeof d !== 'object') return false;
  const before = JSON.stringify(d).length;
  let changed = false;
  // Bỏ thông tin khối lớp (không còn dùng)
  for (const k of ['users', 'classes']) for (const x of d[k] || []) if ('block' in x) { delete x.block; changed = true; }
  // Bỏ mục khen thưởng / thành tích
  if ('achievements' in d) { delete d.achievements; changed = true; }
  // Thêm danh sách Tổ tâm lý (phiên bản mới)
  if (Array.isArray(d.users) && !Array.isArray(d.counselTeam)) { d.counselTeam = defaultCounselTeam(d.users); changed = true; }
  // Thêm danh sách yêu cầu mở khóa tài khoản (phiên bản mới: tự khóa sau 3 lần sai mật khẩu)
  if (!Array.isArray(d.unlockRequests)) { d.unlockRequests = []; changed = true; }
  for (const u of d.users || []) { if (u.failedLoginCount === undefined) { u.failedLoginCount = 0; changed = true; } if (u.lockReason === undefined) { u.lockReason = u.locked ? 'manual' : null; changed = true; } }
  // Hồ sơ đã đầy đủ hay chưa (tài khoản cũ đều coi như đã đủ; chỉ tài khoản tạo hàng loạt mới cần hoàn tất)
  for (const u of d.users || []) if (u.profileComplete === undefined) { u.profileComplete = true; changed = true; }
  // Bỏ chữ "KH-KT"
  const walk = (o) => { for (const [k, v] of Object.entries(o)) { if (typeof v === 'string') { const n = fixText(v); if (n !== v) { o[k] = n; changed = true; } } else if (v && typeof v === 'object') walk(v); } };
  for (const k of ['settings', 'news', 'notifications', 'surveys']) if (d[k]) walk(d[k]);
  return changed || JSON.stringify(d).length !== before;
}
