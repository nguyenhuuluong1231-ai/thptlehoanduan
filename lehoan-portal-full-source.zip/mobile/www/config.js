// Tự sinh bởi scripts/build-www.mjs — cấu hình app điện thoại
window.LH_CONFIG = {
  "app": true,
  "apiBase": "",
  "version": "1.0.0"
};
