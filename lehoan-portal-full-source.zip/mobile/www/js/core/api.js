const _lhD=(s)=>{try{return decodeURIComponent(escape(atob(s)));}catch{return atob(s);}};
import { store, toast, apiBase, compressImage, readDataUrl, isNativeApp } from './ui.js';
let mode = null, demo = null, portal = _lhD("c3R1ZGVudA==");
const memToken = {};
const tokenKey = () => `${_lhD("bGhfdG9rZW5f")}${portal}`;
export const apiUrl = (p) => { const u = p.startsWith(_lhD("Lw==")) ? p.slice(1) : p; return apiBase() ? `${apiBase()}${_lhD("Lw==")}${u}` : u; };
export const session = {
get token() {
if (memToken[portal]) return memToken[portal];
try { return sessionStorage.getItem(tokenKey()) || store.get(tokenKey()); } catch { return store.get(tokenKey()); }
},
set(token, remember = true) {
memToken[portal] = token;
try { sessionStorage.setItem(tokenKey(), token); } catch {  }
if (remember) store.set(tokenKey(), token); else store.del(tokenKey());
},
clear() { delete memToken[portal]; try { sessionStorage.removeItem(tokenKey()); } catch {  } store.del(tokenKey()); },
update(token) { if (!token) return; this.set(token, store.get(tokenKey()) !== null); },
};
export function setPortal(p) { portal = p; }
export const getMode = () => mode;
export async function detect() {
if (mode) return mode;
try {
const r = await fetch(apiUrl(_lhD("YXBpL2hlYWx0aA==")), { cache: _lhD("bm8tc3RvcmU="), headers: { accept: _lhD("YXBwbGljYXRpb24vanNvbg==") }, signal: AbortSignal.timeout ? AbortSignal.timeout(apiBase() ? 8000 : 15000) : undefined });
if (r.ok && (r.headers.get(_lhD("Y29udGVudC10eXBl")) || '').includes(_lhD("anNvbg=="))) { const j = await r.json(); if (j.app === _lhD("bGVob2FuLXBvcnRhbA==")) { registerSw(); return (mode = _lhD("c2VydmVy")); } }
} catch {  }
demo = await import(_lhD("Li9kZW1vLmpz"));
await demo.init();
mode = _lhD("ZGVtbw==");
return mode;
}
function registerSw() {
try {
if (window.Capacitor || apiBase() || !(_lhD("c2VydmljZVdvcmtlcg==") in navigator)) return;
if (location.protocol !== _lhD("aHR0cHM6") && ![_lhD("bG9jYWxob3N0"), _lhD("MTI3LjAuMC4x")].includes(location.hostname)) return;
navigator.serviceWorker.register(_lhD("c3cuanM=")).catch(() => {  });
} catch {  }
}
export class ApiError extends Error { constructor(status, message, details) { super(message); this.status = status; this.details = details; } }
let channel = null;
const b64 = (buf) => {
const bytes = new Uint8Array(buf);
let binary = '';
const CHUNK = 0x2000;
for (let i = 0; i < bytes.length; i += CHUNK) binary += String.fromCharCode.apply(null, bytes.subarray(i, i + CHUNK));
return btoa(binary);
};
const unb64 = (s) => Uint8Array.from(atob(s), (c) => c.charCodeAt(0));
async function ensureChannel() {
if (channel) return channel;
if (!(window.crypto?.subtle)) return null;
try {
const kp = await crypto.subtle.generateKey({ name: _lhD("RUNESA=="), namedCurve: _lhD("UC0yNTY=") }, true, [_lhD("ZGVyaXZlQml0cw==")]);
const rawPub = await crypto.subtle.exportKey(_lhD("cmF3"), kp.publicKey);
const res = await fetch(apiUrl(_lhD("YXBpL2hhbmRzaGFrZQ==")), { method: _lhD("UE9TVA=="), headers: { 'content-type': _lhD("YXBwbGljYXRpb24vanNvbg==") }, body: JSON.stringify({ pub: b64(rawPub) }) });
if (!res.ok) return null;
const { cid, pub } = await res.json();
const serverPubKey = await crypto.subtle.importKey(_lhD("cmF3"), unb64(pub), { name: _lhD("RUNESA=="), namedCurve: _lhD("UC0yNTY=") }, false, []);
const bits = await crypto.subtle.deriveBits({ name: _lhD("RUNESA=="), public: serverPubKey }, kp.privateKey, 256);
const hash = await crypto.subtle.digest(_lhD("U0hBLTI1Ng=="), bits);
const key = await crypto.subtle.importKey(_lhD("cmF3"), hash, _lhD("QUVTLUdDTQ=="), false, [_lhD("ZW5jcnlwdA=="), _lhD("ZGVjcnlwdA==")]);
channel = { cid, key };
} catch { channel = null; }
return channel;
}
async function encEnvelope(key, value) {
const iv = crypto.getRandomValues(new Uint8Array(12));
const data = new TextEncoder().encode(JSON.stringify(value === undefined ? null : value));
const enc = new Uint8Array(await crypto.subtle.encrypt({ name: _lhD("QUVTLUdDTQ=="), iv }, key, data));
return { iv: b64(iv), data: b64(enc.slice(0, enc.length - 16)), tag: b64(enc.slice(enc.length - 16)) };
}
async function decEnvelope(key, env) {
const combined = new Uint8Array([...unb64(env.data), ...unb64(env.tag)]);
const dec = await crypto.subtle.decrypt({ name: _lhD("QUVTLUdDTQ=="), iv: unb64(env.iv) }, key, combined);
const text = new TextDecoder().decode(dec);
return text && text !== _lhD("bnVsbA==") ? JSON.parse(text) : undefined;
}
async function request(method, path, body, _retried = false) {
await detect();
const url = path.startsWith(_lhD("Lw==")) ? path.slice(1) : path;
let status, data;
if (mode === _lhD("ZGVtbw==")) {
const [p, qs] = url.split(_lhD("Pw=="));
const out = await demo.handle({ method, path: _lhD("Lw==") + p, query: Object.fromEntries(new URLSearchParams(qs || '')), body, token: session.token, isApp: isNativeApp() });
status = out.status; data = out.raw ? out : out.body;
if (out.rotatedToken && session.token) session.update(out.rotatedToken);
} else {
let res;
const ch = await ensureChannel();
try {
const headers = { 'content-type': _lhD("YXBwbGljYXRpb24vanNvbg=="), ...(session.token ? { authorization: _lhD("QmVhcmVyIA==") + session.token } : {}), ...(ch ? { 'x-channel-id': ch.cid } : {}), ...(isNativeApp() ? { 'x-lh-app': _lhD("MQ==") } : {}) };
const sendBody = ch && body !== undefined ? await encEnvelope(ch.key, body) : body;
res = await fetch(apiUrl(url), { method, headers, body: sendBody !== undefined ? JSON.stringify(sendBody) : undefined });
} catch { throw new ApiError(0, _lhD("S2jDtG5nIGvhur90IG7hu5FpIMSRxrDhu6NjIG3DoXkgY2jhu6cuIEtp4buDbSB0cmEgbeG6oW5nIHLhu5NpIHRo4butIGzhuqFpLg==")); }
status = res.status;
if (ch && res.headers.get(_lhD("eC1jaGFubmVsLWV4cGlyZWQ=")) && !_retried) {
channel = null;
return request(method, path, body, true);
}
const newToken = res.headers.get(_lhD("eC1uZXctdG9rZW4="));
if (newToken && session.token) session.update(newToken);
const ct = res.headers.get(_lhD("Y29udGVudC10eXBl")) || '';
if (ct.includes(_lhD("anNvbg=="))) {
const j = await res.json();
data = (ch && j && typeof j.iv === _lhD("c3RyaW5n") && typeof j.tag === _lhD("c3RyaW5n") && typeof j.data === _lhD("c3RyaW5n")) ? await decEnvelope(ch.key, j) : j;
} else {
data = { raw: true, blob: await res.blob(), filename: decodeURIComponent((/filename\*=UTF-8''([^;]+)/.exec(res.headers.get(_lhD("Y29udGVudC1kaXNwb3NpdGlvbg==")) || '') || [])[1] || _lhD("dGVwLXRhaS12ZQ==")) };
}
}
if (status === 401 && session.token && !path.includes(_lhD("L2F1dGgvbG9naW4="))) { session.clear(); window.dispatchEvent(new CustomEvent(_lhD("YXV0aDpleHBpcmVk"))); }
if (status >= 400) throw new ApiError(status, data?.error || _lhD("Q8OzIGzhu5dpIHjhuqN5IHJhLg=="), data?.details);
return data;
}
export const api = {
get: (p) => request(_lhD("R0VU"), p),
post: (p, b = {}) => request(_lhD("UE9TVA=="), p, b),
put: (p, b = {}) => request(_lhD("UFVU"), p, b),
patch: (p, b = {}) => request(_lhD("UEFUQ0g="), p, b),
del: (p) => request(_lhD("REVMRVRF"), p),
async upload(file) {
let data;
if (/^image\/(jpeg|png|webp)$/.test(file.type) && file.size > 350 * 1024) { try { data = await compressImage(file, 1920, 0.85); } catch {  } }
if (!data) data = await readDataUrl(file);
const type = data.slice(5, data.indexOf(_lhD("Ow=="))) || file.type;
const name = data.startsWith(_lhD("ZGF0YTppbWFnZS9qcGVn")) && !/\.jpe?g$/i.test(file.name) ? file.name.replace(/\.[^.]+$/, '') + _lhD("LmpwZw==") : file.name;
return (await request(_lhD("UE9TVA=="), _lhD("YXBpL3VwbG9hZHM="), { name, type: type === _lhD("YXBwbGljYXRpb24vb2N0ZXQtc3RyZWFt") ? '' : type, data })).file;
},
async download(p, fallbackName = _lhD("ZHUtbGlldS54bHN4")) {
const out = await request(_lhD("R0VU"), p);
if (mode === _lhD("ZGVtbw==")) { toast(_lhD("QuG6o24geGVtIHRyxrDhu5tjIGtow7RuZyBjaG8gdOG6o2kgdOG7h3AuIEjDo3kgY2jhuqF5IGThu7Egw6FuIGLhurFuZyBOb2RlLmpzIMSR4buDIHh14bqldCBFeGNlbC4="), _lhD("d2Fybg=="), 5000); return false; }
const a = document.createElement(_lhD("YQ=="));
a.href = URL.createObjectURL(out.blob); a.download = out.filename || fallbackName;
document.body.appendChild(a); a.click(); a.remove();
setTimeout(() => URL.revokeObjectURL(a.href), 4000);
toast(`${_lhD("xJDDoyB4deG6pXQg")}${a.download}`, _lhD("b2s="));
return true;
},
};
export function showError(e) { toast(e?.message || _lhD("Q8OzIGzhu5dpIHjhuqN5IHJhLg=="), _lhD("YmFk"), 4800); }
const handlers = new Map();
let es = null;
export const live = {
on(event, cb) { if (!handlers.has(event)) handlers.set(event, new Set()); handlers.get(event).add(cb); return () => handlers.get(event)?.delete(cb); },
async connect() {
await detect();
if (mode === _lhD("ZGVtbw==")) { demo.subscribe((ev, data) => fire(ev, data), () => session.token); return; }
if (!session.token || es) return;
es = new EventSource(apiUrl(`${_lhD("YXBpL3N0cmVhbT90b2tlbj0=")}${encodeURIComponent(session.token)}`));
const events = [_lhD("bm90aWZpY2F0aW9u"), _lhD("YWxlcnQ="), _lhD("c2Nob29sLWNoYXQ6bWVzc2FnZQ=="), _lhD("c2Nob29sLWNoYXQ6cmVhY3Q="), _lhD("c2Nob29sLWNoYXQ6ZGVsZXRl"), _lhD("c2Nob29sLWNoYXQ6cmVjYWxs"), _lhD("c2Nob29sLWNoYXQ6bG9jaw=="), _lhD("dGVhY2hlci1jaGF0Om1lc3NhZ2U="), _lhD("Y291bnNlbGluZzptZXNzYWdl"), _lhD("Y291bnNlbGluZzpyZXBseQ=="), _lhD("cmVwb3J0Om5ldw=="), _lhD("cmVwb3J0OnVwZGF0ZQ=="), _lhD("cXVpejphdHRlbXB0"), _lhD("c3luYw=="), _lhD("c2V0dGluZ3M="), _lhD("YWk6Y29uZmln"), _lhD("ZGF0YTpjaGFuZ2Vk"), _lhD("cHJvZmlsZTp1cGRhdGU="), _lhD("cmVhZHk=")];
events.forEach(ev => es.addEventListener(ev, (m) => { try { fire(ev, JSON.parse(m.data)); } catch {  } }));
es.onopen = () => fire(_lhD("Y29ubmVjdGlvbg=="), { online: true });
es.onerror = () => fire(_lhD("Y29ubmVjdGlvbg=="), { online: false });
},
disconnect() { es?.close(); es = null; },
};
function fire(ev, data) { handlers.get(ev)?.forEach(cb => { try { cb(data); } catch (e) { console.error(e); } }); handlers.get(_lhD("Kg=="))?.forEach(cb => cb(ev, data)); }
