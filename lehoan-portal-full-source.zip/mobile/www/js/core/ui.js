const _lhD=(s)=>{try{return decodeURIComponent(escape(atob(s)));}catch{return atob(s);}};
import { icon } from './icons.js';
export const $ = (sel, root = document) => root.querySelector(sel);
export const $$ = (sel, root = document) => [...root.querySelectorAll(sel)];
export const esc = (s) => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': _lhD("JmFtcDs="), '<': _lhD("Jmx0Ow=="), '>': _lhD("Jmd0Ow=="), '"': _lhD("JnF1b3Q7"), "'": _lhD("JiMzOTs=") }[c]));
export const sleep = (ms) => new Promise(r => setTimeout(r, ms));
export const store = {
get(k, d = null) { try { const v = localStorage.getItem(k); return v === null ? d : JSON.parse(v); } catch { return d; } },
set(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch {  } },
del(k) { try { localStorage.removeItem(k); } catch {  } },
};
const pad = (n) => String(n).padStart(2, _lhD("MA=="));
export const fmtDate = (iso) => { if (!iso) return _lhD("4oCU"); const d = new Date(iso); return `${pad(d.getDate())}${_lhD("Lw==")}${pad(d.getMonth() + 1)}${_lhD("Lw==")}${d.getFullYear()}`; };
export const fmtTime = (iso) => { if (!iso) return ''; const d = new Date(iso); return `${pad(d.getHours())}${_lhD("Og==")}${pad(d.getMinutes())}`; };
export const fmtDateTime = (iso) => iso ? `${fmtTime(iso)}${_lhD("IMK3IA==")}${fmtDate(iso)}` : _lhD("4oCU");
export const DAY = [_lhD("Q2jhu6cgbmjhuq10"), _lhD("VGjhu6kgSGFp"), _lhD("VGjhu6kgQmE="), _lhD("VGjhu6kgVMaw"), _lhD("VGjhu6kgTsSDbQ=="), _lhD("VGjhu6kgU8OhdQ=="), _lhD("VGjhu6kgQuG6o3k=")];
export const DAY_SHORT = [_lhD("Q04="), _lhD("VDI="), _lhD("VDM="), _lhD("VDQ="), _lhD("VDU="), _lhD("VDY="), _lhD("VDc=")];
export function ago(iso) {
if (!iso) return '';
const s = (Date.now() - new Date(iso).getTime()) / 1000;
if (s < 45) return _lhD("VuG7q2EgeG9uZw==");
if (s < 3600) return `${Math.round(s / 60)}${_lhD("IHBow7p0IHRyxrDhu5tj")}`;
if (s < 86400) return `${Math.round(s / 3600)}${_lhD("IGdp4budIHRyxrDhu5tj")}`;
if (s < 86400 * 2) return _lhD("SMO0bSBxdWE=");
if (s < 86400 * 7) return `${Math.floor(s / 86400)}${_lhD("IG5nw6B5IHRyxrDhu5tj")}`;
return fmtDate(iso);
}
export const vnd = (n) => new Intl.NumberFormat(_lhD("dmktVk4=")).format(Math.round(n || 0)) + _lhD("IMSR");
export const num = (n, d = 0) => n === null || n === undefined || Number.isNaN(n) ? _lhD("4oCU") : Number(n).toLocaleString(_lhD("dmktVk4="), { minimumFractionDigits: d, maximumFractionDigits: d });
export const greeting = () => { const h = new Date().getHours(); return h < 11 ? _lhD("Q2jDoG8gYnXhu5VpIHPDoW5n") : h < 13 ? _lhD("Q2jDoG8gYnXhu5VpIHRyxrBh") : h < 18 ? _lhD("Q2jDoG8gYnXhu5VpIGNoaeG7gXU=") : _lhD("Q2jDoG8gYnXhu5VpIHThu5Fp"); };
export const firstName = (n = '') => n.replace(/^(ThS\.|TS\.|Thầy|Cô)\s*/i, '').trim().split(/\s+/).pop();
const AV_COLORS = [_lhD("IzE3NDdjOQ=="), _lhD("IzBmOGY2Nw=="), _lhD("IzZhNGZlMA=="), _lhD("I2U4NTEzYQ=="), _lhD("IzBhODRiOA=="), _lhD("I2IwMzY3YQ=="), _lhD("I2MyN2MwZQ=="), _lhD("IzJmNmI0Zg==")];
export function avatar(u, cls = '') {
const name = u?.name || _lhD("Pw==");
const parts = name.replace(/^(ThS\.|TS\.|Thầy|Cô)\s*/i, '').trim().split(/\s+/);
const ini = ((parts.at(-2)?.[0] || '') + (parts.at(-1)?.[0] || '')).toUpperCase();
let h = 0; for (const c of (u?.id || name)) h = (h * 31 + c.charCodeAt(0)) >>> 0;
if (u?.avatar) return `${_lhD("PHNwYW4gY2xhc3M9ImF2YXRhciA=")}${cls}${_lhD("Ij48aW1nIHNyYz0i")}${esc(u.avatar)}${_lhD("IiBhbHQ9IiIgbG9hZGluZz0ibGF6eSI+PC9zcGFuPg==")}`;
return `${_lhD("PHNwYW4gY2xhc3M9ImF2YXRhciA=")}${cls}${_lhD("IiBzdHlsZT0iYmFja2dyb3VuZDo=")}${AV_COLORS[h % AV_COLORS.length]}${_lhD("IiBhcmlhLWhpZGRlbj0idHJ1ZSI+")}${esc(ini)}${_lhD("PC9zcGFuPg==")}`;
}
export function md(text = '') {
const blocks = [];
let t = esc(text).replace(/```([\s\S]*?)```/g, (_, code) => { blocks.push(`${_lhD("PHByZT4=")}${code.replace(/^\n/, '')}${_lhD("PC9wcmU+")}`); return `${_lhD("AA==")}${blocks.length - 1}${_lhD("AA==")}`; });
t = t.replace(/\*\*(.+?)\*\*/g, _lhD("PHN0cm9uZz4kMTwvc3Ryb25nPg==")).replace(/(^|[^*])\*(?!\s)(.+?)\*(?!\*)/g, _lhD("JDE8ZW0+JDI8L2VtPg==")).replace(/`([^`]+)`/g, _lhD("PGNvZGU+JDE8L2NvZGU+"));
const lines = t.split(_lhD("Cg==")); const out = []; let list = null;
for (const line of lines) {
const ul = /^\s*[-•]\s+(.*)/.exec(line), ol = /^\s*(\d+)[.)]\s+(.*)/.exec(line);
if (ul || ol) {
const type = ul ? _lhD("dWw=") : _lhD("b2w=");
if (list !== type) { if (list) out.push(`${_lhD("PC8=")}${list}${_lhD("Pg==")}`); out.push(`${_lhD("PA==")}${type}${_lhD("Pg==")}`); list = type; }
out.push(`${_lhD("PGxpPg==")}${(ul || ol)[ul ? 1 : 2]}${_lhD("PC9saT4=")}`);
} else {
if (list) { out.push(`${_lhD("PC8=")}${list}${_lhD("Pg==")}`); list = null; }
if (line.trim()) out.push(`${_lhD("PHA+")}${line}${_lhD("PC9wPg==")}`);
}
}
if (list) out.push(`${_lhD("PC8=")}${list}${_lhD("Pg==")}`);
return out.join('').replace(/<p>\u0000(\d+)\u0000<\/p>|\u0000(\d+)\u0000/g, (_, a, b) => blocks[a ?? b]);
}
let toastHost;
export function toast(message, tone = _lhD("aW5mbw=="), ms = 3600) {
if (!toastHost) { toastHost = document.createElement(_lhD("ZGl2")); toastHost.className = _lhD("dG9hc3Rz"); toastHost.setAttribute(_lhD("cm9sZQ=="), _lhD("c3RhdHVz")); toastHost.setAttribute(_lhD("YXJpYS1saXZl"), _lhD("cG9saXRl")); document.body.appendChild(toastHost); }
const el = document.createElement(_lhD("ZGl2"));
el.className = `${_lhD("dG9hc3Qg")}${tone}`;
el.innerHTML = `${icon(tone === _lhD("b2s=") ? _lhD("Y2hlY2tDaXJjbGU=") : tone === _lhD("YmFk") ? _lhD("YWxlcnRDaXJjbGU=") : tone === _lhD("d2Fybg==") ? _lhD("YWxlcnQ=") : _lhD("aW5mbw=="))}${_lhD("PHNwYW4+")}${esc(message)}${_lhD("PC9zcGFuPg==")}`;
toastHost.appendChild(el);
setTimeout(() => { el.classList.add(_lhD("b3V0")); setTimeout(() => el.remove(), 260); }, ms);
}
export function modal({ title, sub = '', body = '', foot = '', size = '', onMount, onClose } = {}) {
const back = document.createElement(_lhD("ZGl2"));
back.className = _lhD("YmFja2Ryb3A=");
back.innerHTML = `${_lhD("PGRpdiBjbGFzcz0ibW9kYWwg")}${size}${_lhD("IiByb2xlPSJkaWFsb2ciIGFyaWEtbW9kYWw9InRydWUiIGFyaWEtbGFiZWw9Ig==")}${esc(title)}${_lhD("Ij4KICAgIDxkaXYgY2xhc3M9Im1vZGFsLWhlYWQiPjxoMz4=")}${esc(title)}${sub ? `${_lhD("PGRpdiBjbGFzcz0ic3ViIj4=")}${sub}${_lhD("PC9kaXY+")}` : ''}${_lhD("PC9oMz48YnV0dG9uIGNsYXNzPSJidG4gaWNvbiBnaG9zdCBzbSIgZGF0YS1jbG9zZSBhcmlhLWxhYmVsPSLEkMOzbmciPg==")}${icon(_lhD("eA=="))}${_lhD("PC9idXR0b24+PC9kaXY+CiAgICA8ZGl2IGNsYXNzPSJtb2RhbC1ib2R5Ij4=")}${body}${_lhD("PC9kaXY+")}${foot ? `${_lhD("PGRpdiBjbGFzcz0ibW9kYWwtZm9vdCI+")}${foot}${_lhD("PC9kaXY+")}` : ''}${_lhD("PC9kaXY+")}`;
const prevFocus = document.activeElement;
const close = (v) => { back.remove(); document.removeEventListener(_lhD("a2V5ZG93bg=="), onKey); onClose?.(v); prevFocus?.focus?.(); };
const onKey = (e) => { if (e.key === _lhD("RXNjYXBl")) close(); };
back.addEventListener(_lhD("bW91c2Vkb3du"), (e) => { if (e.target === back) close(); });
back.querySelectorAll(_lhD("W2RhdGEtY2xvc2Vd")).forEach(b => b.addEventListener(_lhD("Y2xpY2s="), () => close()));
document.addEventListener(_lhD("a2V5ZG93bg=="), onKey);
document.body.appendChild(back);
const m = back.querySelector(_lhD("Lm1vZGFs"));
onMount?.(m, close);
setTimeout(() => (m.querySelector(_lhD("W2F1dG9mb2N1c10=")) || m.querySelector(_lhD("aW5wdXQsdGV4dGFyZWEsc2VsZWN0LGJ1dHRvbjpub3QoW2RhdGEtY2xvc2VdKQ==")))?.focus(), 30);
return { el: m, close };
}
export function confirmDialog({ title = _lhD("WMOhYyBuaOG6rW4="), message = '', ok = _lhD("xJDhu5NuZyDDvQ=="), tone = '', cancel = _lhD("SOG7p3k=") } = {}) {
return new Promise((resolve) => {
let answered = false;
modal({ title, body: `${_lhD("PHAgY2xhc3M9ImluazIiPg==")}${message}${_lhD("PC9wPg==")}`, foot: `${_lhD("PGJ1dHRvbiBjbGFzcz0iYnRuIGdob3N0IiBkYXRhLWNsb3NlPg==")}${cancel}${_lhD("PC9idXR0b24+PGJ1dHRvbiBjbGFzcz0iYnRuIA==")}${tone}${_lhD("IiBkYXRhLW9rPg==")}${ok}${_lhD("PC9idXR0b24+")}`,
onMount: (m, close) => m.querySelector(_lhD("W2RhdGEtb2td")).addEventListener(_lhD("Y2xpY2s="), () => { answered = true; close(); resolve(true); }),
onClose: () => { if (!answered) resolve(false); } });
});
}
export function drawer({ title, body = '', onMount }) {
const back = document.createElement(_lhD("ZGl2")); back.className = _lhD("ZHJhd2VyLWJhY2s=");
const d = document.createElement(_lhD("YXNpZGU=")); d.className = _lhD("ZHJhd2Vy"); d.setAttribute(_lhD("cm9sZQ=="), _lhD("ZGlhbG9n")); d.setAttribute(_lhD("YXJpYS1sYWJlbA=="), title);
d.innerHTML = `${_lhD("PGRpdiBjbGFzcz0iZHJhd2VyLWhlYWQiPjxoMz4=")}${esc(title)}${_lhD("PC9oMz48YnV0dG9uIGNsYXNzPSJidG4gaWNvbiBnaG9zdCBzbSIgZGF0YS1jbG9zZSBhcmlhLWxhYmVsPSLEkMOzbmciPg==")}${icon(_lhD("eA=="))}${_lhD("PC9idXR0b24+PC9kaXY+PGRpdiBjbGFzcz0iZHJhd2VyLWJvZHkiPg==")}${body}${_lhD("PC9kaXY+")}`;
const close = () => { back.remove(); d.remove(); document.removeEventListener(_lhD("a2V5ZG93bg=="), onKey); };
const onKey = (e) => { if (e.key === _lhD("RXNjYXBl")) close(); };
back.addEventListener(_lhD("Y2xpY2s="), close); d.querySelector(_lhD("W2RhdGEtY2xvc2Vd")).addEventListener(_lhD("Y2xpY2s="), close);
document.addEventListener(_lhD("a2V5ZG93bg=="), onKey);
document.body.append(back, d);
onMount?.(d, close);
return { el: d, close };
}
export function formData(form) {
const o = {};
for (const el of form.elements) {
if (!el.name || el.disabled) continue;
if (el.type === _lhD("Y2hlY2tib3g=")) { if (form.querySelectorAll(`${_lhD("W25hbWU9Ig==")}${el.name}${_lhD("Il0=")}`).length > 1) { (o[el.name] ||= []); if (el.checked) o[el.name].push(el.value); } else o[el.name] = el.checked; }
else if (el.type === _lhD("cmFkaW8=")) { if (el.checked) o[el.name] = el.value; else if (!(el.name in o)) o[el.name] = ''; }
else o[el.name] = el.value;
}
return o;
}
export async function withBusy(btn, fn) {
if (!btn) return fn();
btn.classList.add(_lhD("bG9hZGluZw==")); btn.disabled = true;
try { return await fn(); } finally { btn.classList.remove(_lhD("bG9hZGluZw==")); btn.disabled = false; }
}
export function compressImage(file, max = 1280, quality = .82) {
return new Promise((resolve, reject) => {
if (!file.type.startsWith(_lhD("aW1hZ2Uv"))) return reject(new Error(_lhD("VnVpIGzDsm5nIGNo4buNbiB04buHcCBow6xuaCDhuqNuaC4=")));
const reader = new FileReader();
reader.onerror = () => reject(new Error(_lhD("S2jDtG5nIMSR4buNYyDEkcaw4bujYyDhuqNuaC4=")));
reader.onload = () => {
const img = new Image();
img.onload = () => {
const s = Math.min(1, max / Math.max(img.width, img.height));
const c = document.createElement(_lhD("Y2FudmFz")); c.width = Math.round(img.width * s); c.height = Math.round(img.height * s);
c.getContext(_lhD("MmQ=")).drawImage(img, 0, 0, c.width, c.height);
resolve(c.toDataURL(_lhD("aW1hZ2UvanBlZw=="), quality));
};
img.onerror = () => reject(new Error(_lhD("4bqibmgga2jDtG5nIGjhu6NwIGzhu4cu")));
img.src = reader.result;
};
reader.readAsDataURL(file);
});
}
export async function copyText(text) {
try { await navigator.clipboard.writeText(text); toast(_lhD("xJDDoyBzYW8gY2jDqXA="), _lhD("b2s="), 1800); }
catch { const t = document.createElement(_lhD("dGV4dGFyZWE=")); t.value = text; document.body.appendChild(t); t.select(); try { document.execCommand(_lhD("Y29weQ==")); toast(_lhD("xJDDoyBzYW8gY2jDqXA="), _lhD("b2s="), 1800); } catch { toast(_lhD("S2jDtG5nIHNhbyBjaMOpcCDEkcaw4bujYywgaMOjeSBjaOG7jW4gdsOgIHNhbyBjaMOpcCB0aOG7pyBjw7RuZy4="), _lhD("d2Fybg==")); } t.remove(); }
}
export const empty = (title, text = '', ico = _lhD("c3BhcmtsZXM="), action = '') => `${_lhD("PGRpdiBjbGFzcz0iZW1wdHkiPjxkaXYgY2xhc3M9ImFydCI+")}${icon(ico)}${_lhD("PC9kaXY+PGg0Pg==")}${esc(title)}${_lhD("PC9oND4=")}${text ? `${_lhD("PHAgY2xhc3M9InNtYWxsIj4=")}${text}${_lhD("PC9wPg==")}` : ''}${action}${_lhD("PC9kaXY+")}`;
export const skeleton = (rows = 3) => `${_lhD("PGRpdiBjbGFzcz0ibG9hZGluZy1wYWdlIj4=")}${_lhD("PGRpdiBjbGFzcz0ic2tlbCIgc3R5bGU9ImhlaWdodDoxMjBweCI+PC9kaXY+").repeat(rows)}${_lhD("PC9kaXY+")}`;
export const badge = (text, tone = '') => `${_lhD("PHNwYW4gY2xhc3M9ImJhZGdlIA==")}${tone}${_lhD("Ij4=")}${esc(text)}${_lhD("PC9zcGFuPg==")}`;
export function barChart(data, { height = 180, width = 560, max = null, unit = '', color = _lhD("dmFyKC0tYnJhbmQp"), format = (v) => v } = {}) {
const W = Math.max(280, Math.round(width)), H = height, padL = 38, padB = 26, padT = 16;
const top = max ?? Math.max(1, ...data.map(d => d.value ?? 0));
const nice = top <= 5 ? 5 : top <= 10 ? 10 : Math.ceil(top / (top > 50 ? 25 : 5)) * (top > 50 ? 25 : 5);
const bw = (W - padL - 10) / data.length;
const y = (v) => H - padB - ((v ?? 0) / nice) * (H - padB - padT);
const ticks = [0, nice / 2, nice];
return `${_lhD("PHN2ZyBjbGFzcz0iY2hhcnQiIHZpZXdCb3g9IjAgMCA=")}${W} ${H}${_lhD("IiByb2xlPSJpbWciIGFyaWEtbGFiZWw9IkJp4buDdSDEkeG7kyBj4buZdCI+CiAgICA=")}${ticks.map(t => `${_lhD("PGxpbmUgY2xhc3M9ImdyaWQtbGluZSIgeDE9Ig==")}${padL}${_lhD("IiB4Mj0i")}${W - 6}${_lhD("IiB5MT0i")}${y(t)}${_lhD("IiB5Mj0i")}${y(t)}${_lhD("Ii8+PHRleHQgeD0i")}${padL - 8}${_lhD("IiB5PSI=")}${y(t) + 4}${_lhD("IiB0ZXh0LWFuY2hvcj0iZW5kIj4=")}${format(t)}${unit}${_lhD("PC90ZXh0Pg==")}`).join('')}
${data.map((d, i) => { const w = Math.min(bw * .6, 72), x = padL + i * bw + (bw - w) / 2, yy = y(d.value), h = H - padB - yy; return `${_lhD("PHJlY3QgeD0i")}${x.toFixed(1)}${_lhD("IiB5PSI=")}${yy.toFixed(1)}${_lhD("IiB3aWR0aD0i")}${w.toFixed(1)}${_lhD("IiBoZWlnaHQ9Ig==")}${Math.max(0, h).toFixed(1)}${_lhD("IiByeD0iNiIgZmlsbD0i")}${d.value === null ? _lhD("dmFyKC0tc3VyZmFjZS0zKQ==") : d.color || color}${_lhD("Ij48dGl0bGU+")}${esc(d.label)}${_lhD("OiA=")}${d.value ?? _lhD("4oCU")}${unit}${_lhD("PC90aXRsZT48L3JlY3Q+")}${d.value !== null && d.value !== undefined ? `${_lhD("PHRleHQgeD0i")}${(x + w / 2).toFixed(1)}${_lhD("IiB5PSI=")}${(yy - 5).toFixed(1)}${_lhD("IiB0ZXh0LWFuY2hvcj0ibWlkZGxlIiBzdHlsZT0iZmlsbDp2YXIoLS1pbmstMik7Zm9udC13ZWlnaHQ6NjAwIj4=")}${format(d.value)}${_lhD("PC90ZXh0Pg==")}` : ''}${_lhD("PHRleHQgeD0i")}${(x + w / 2).toFixed(1)}${_lhD("IiB5PSI=")}${H - 8}${_lhD("IiB0ZXh0LWFuY2hvcj0ibWlkZGxlIj4=")}${esc(d.label)}${_lhD("PC90ZXh0Pg==")}`; }).join('')}${_lhD("CiAgPC9zdmc+")}`;
}
export function donut(data, { size = 160, thickness = 22, center = '', sub = '' } = {}) {
const total = data.reduce((a, d) => a + d.value, 0) || 1;
const r = (size - thickness) / 2, c = 2 * Math.PI * r; let off = 0;
const arcs = data.filter(d => d.value > 0).map(d => { const len = (d.value / total) * c; const s = `${_lhD("PGNpcmNsZSByPSI=")}${r}${_lhD("IiBjeD0i")}${size / 2}${_lhD("IiBjeT0i")}${size / 2}${_lhD("IiBmaWxsPSJub25lIiBzdHJva2U9Ig==")}${d.color}${_lhD("IiBzdHJva2Utd2lkdGg9Ig==")}${thickness}${_lhD("IiBzdHJva2UtZGFzaGFycmF5PSI=")}${len.toFixed(2)} ${(c - len).toFixed(2)}${_lhD("IiBzdHJva2UtZGFzaG9mZnNldD0i")}${(-off).toFixed(2)}${_lhD("Ij48dGl0bGU+")}${esc(d.label)}${_lhD("OiA=")}${d.value}${_lhD("PC90aXRsZT48L2NpcmNsZT4=")}`; off += len; return s; }).join('');
return `${_lhD("PHN2ZyB3aWR0aD0i")}${size}${_lhD("IiBoZWlnaHQ9Ig==")}${size}${_lhD("IiB2aWV3Qm94PSIwIDAg")}${size} ${size}${_lhD("IiBzdHlsZT0ibWF4LXdpZHRoOjEwMCU7aGVpZ2h0OmF1dG8iIHJvbGU9ImltZyIgYXJpYS1sYWJlbD0iQmnhu4N1IMSR4buTIHThu7cgbOG7hyI+PGcgdHJhbnNmb3JtPSJyb3RhdGUoLTkwIA==")}${size / 2} ${size / 2}${_lhD("KSI+PGNpcmNsZSByPSI=")}${r}${_lhD("IiBjeD0i")}${size / 2}${_lhD("IiBjeT0i")}${size / 2}${_lhD("IiBmaWxsPSJub25lIiBzdHJva2U9InZhcigtLXN1cmZhY2UtMykiIHN0cm9rZS13aWR0aD0i")}${thickness}${_lhD("Ii8+")}${arcs}${_lhD("PC9nPgogICAgPHRleHQgeD0iNTAlIiB5PSI=")}${center && sub ? _lhD("NDgl") : _lhD("NTMl")}${_lhD("IiB0ZXh0LWFuY2hvcj0ibWlkZGxlIiBzdHlsZT0iZm9udDo2MDAgMjJweCB2YXIoLS1mb250LWRpc3BsYXkpO2ZpbGw6dmFyKC0taW5rKSI+")}${esc(center)}${_lhD("PC90ZXh0Pg==")}${sub ? `${_lhD("PHRleHQgeD0iNTAlIiB5PSI2MiUiIHRleHQtYW5jaG9yPSJtaWRkbGUiIHN0eWxlPSJmb250OjUwMCAxMXB4IHZhcigtLWZvbnQtYm9keSk7ZmlsbDp2YXIoLS1tdXRlZCkiPg==")}${esc(sub)}${_lhD("PC90ZXh0Pg==")}` : ''}${_lhD("PC9zdmc+")}`;
}
export function sparkline(values, { width = 120, height = 36, color = _lhD("dmFyKC0tYnJhbmQp") } = {}) {
const v = values.map(x => x ?? 0); const max = Math.max(...v, 1), min = Math.min(...v, 0);
const pts = v.map((x, i) => [(i / Math.max(1, v.length - 1)) * width, height - 4 - ((x - min) / (max - min || 1)) * (height - 8)]);
const d = pts.map((p, i) => `${i ? _lhD("TA==") : _lhD("TQ==")}${p[0].toFixed(1)} ${p[1].toFixed(1)}`).join('');
return `${_lhD("PHN2ZyB3aWR0aD0i")}${width}${_lhD("IiBoZWlnaHQ9Ig==")}${height}${_lhD("IiB2aWV3Qm94PSIwIDAg")}${width} ${height}${_lhD("IiBzdHlsZT0ibWF4LXdpZHRoOjEwMCUiPjxwYXRoIGQ9Ig==")}${d}${_lhD("IEw=")}${width} ${height}${_lhD("IEwwIA==")}${height}${_lhD("WiIgZmlsbD0i")}${color}${_lhD("IiBvcGFjaXR5PSIuMTIiLz48cGF0aCBkPSI=")}${d}${_lhD("IiBmaWxsPSJub25lIiBzdHJva2U9Ig==")}${color}${_lhD("IiBzdHJva2Utd2lkdGg9IjIiIHN0cm9rZS1saW5lY2FwPSJyb3VuZCIvPjxjaXJjbGUgY3g9Ig==")}${pts.at(-1)[0]}${_lhD("IiBjeT0i")}${pts.at(-1)[1]}${_lhD("IiByPSIzIiBmaWxsPSI=")}${color}${_lhD("Ii8+PC9zdmc+")}`;
}
export function gauge(score, color) {
const a = Math.PI * (1 - score / 100), x = 60 + 46 * Math.cos(a), y = 60 - 46 * Math.sin(a);
return `${_lhD("PHN2ZyBjbGFzcz0iZ2F1Z2UiIHZpZXdCb3g9IjAgMCAxMjAgNzIiIHJvbGU9ImltZyIgYXJpYS1sYWJlbD0ixJBp4buDbSBy4bunaSBybyA=")}${score}${_lhD("LzEwMCI+PHBhdGggZD0iTTE0IDYwIEE0NiA0NiAwIDAgMSAxMDYgNjAiIGZpbGw9Im5vbmUiIHN0cm9rZT0idmFyKC0tc3VyZmFjZS0zKSIgc3Ryb2tlLXdpZHRoPSIxMCIgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIi8+PHBhdGggZD0iTTE0IDYwIEE0NiA0NiAwIDAgMSA=")}${x.toFixed(1)} ${y.toFixed(1)}${_lhD("IiBmaWxsPSJub25lIiBzdHJva2U9Ig==")}${color}${_lhD("IiBzdHJva2Utd2lkdGg9IjEwIiBzdHJva2UtbGluZWNhcD0icm91bmQiLz48dGV4dCB4PSI2MCIgeT0iNTYiIHRleHQtYW5jaG9yPSJtaWRkbGUiIHN0eWxlPSJmb250OjcwMCAyMnB4IHZhcigtLWZvbnQtZGlzcGxheSk7ZmlsbDo=")}${color}${_lhD("Ij4=")}${score}${_lhD("PC90ZXh0Pjx0ZXh0IHg9IjYwIiB5PSI3MCIgdGV4dC1hbmNob3I9Im1pZGRsZSIgc3R5bGU9ImZvbnQ6NTAwIDlweCB2YXIoLS1mb250LWJvZHkpO2ZpbGw6dmFyKC0tbXV0ZWQpIj4vIDEwMCDEkWnhu4NtIHLhu6dpIHJvPC90ZXh0Pjwvc3ZnPg==")}`;
}
const CAT_ICON = { violence: _lhD("c2hpZWxkQWxlcnQ="), scam: _lhD("YWxlcnQ="), drugs: _lhD("cGlsbA=="), explosive: _lhD("Ym9tYg=="), law: _lhD("c2NhbGU="), traffic: _lhD("Y2Fy"), wellbeing: _lhD("aGVhcnRIYW5k"), school: _lhD("c2Nob29s") };
export function cover(n, tag = true) {
return `${_lhD("PGRpdiBjbGFzcz0iY292ZXIiIGRhdGEtY2F0PSI=")}${esc(n.category)}${_lhD("Ij4=")}${n.cover ? `${_lhD("PGltZyBzcmM9Ig==")}${esc(n.cover)}${_lhD("IiBhbHQ9IiIgbG9hZGluZz0ibGF6eSI+")}` : icon(CAT_ICON[n.category] || _lhD("bmV3cw=="))}${tag ? `${_lhD("PHNwYW4gY2xhc3M9ImN2LXRhZyBiYWRnZSBzb2xpZCIgc3R5bGU9ImJhY2tncm91bmQ6cmdiYSgxMCwyMCw1MCwuNTUpO2NvbG9yOiNmZmY7YmFja2Ryb3AtZmlsdGVyOmJsdXIoNnB4KSI+")}${esc(n.badge || '')}${_lhD("PC9zcGFuPg==")}` : ''}${_lhD("PC9kaXY+")}`;
}
export function initTheme() {
const t = store.get(_lhD("dGhlbWU="));
if (t === _lhD("ZGFyaw==") || t === _lhD("bGlnaHQ=")) document.documentElement.dataset.theme = t;
}
export function toggleTheme() {
const cur = document.documentElement.dataset.theme || (matchMedia(_lhD("KHByZWZlcnMtY29sb3Itc2NoZW1lOiBkYXJrKQ==")).matches ? _lhD("ZGFyaw==") : _lhD("bGlnaHQ="));
const next = cur === _lhD("ZGFyaw==") ? _lhD("bGlnaHQ=") : _lhD("ZGFyaw==");
document.documentElement.dataset.theme = next; store.set(_lhD("dGhlbWU="), next);
return next;
}
export function initDevToolsGuard() {
try {
if (new URLSearchParams(location.search).has(_lhD("ZGVidWc=")) || store.get(_lhD("bGhfYWxsb3dfZGV2dG9vbHM="))) return;
document.addEventListener(_lhD("Y29udGV4dG1lbnU="), (e) => e.preventDefault());
document.addEventListener(_lhD("a2V5ZG93bg=="), (e) => {
const k = e.key?.toLowerCase();
if (k === _lhD("ZjEy")) return e.preventDefault();
if ((e.ctrlKey || e.metaKey) && e.shiftKey && [_lhD("aQ=="), _lhD("ag=="), _lhD("Yw==")].includes(k)) return e.preventDefault();
if ((e.ctrlKey || e.metaKey) && k === _lhD("dQ==")) return e.preventDefault();
});
} catch {  }
}
export function idCard(u, settings) {
const bars = [...(u.id || _lhD("MDAwMA=="))].flatMap((c, i) => { const n = c.charCodeAt(0); return [1 + (n % 3), 1 + ((n >> 2) % 2), 2 + ((n + i) % 3)]; }).slice(0, 26);
return `${_lhD("PGRpdiBjbGFzcz0iaWRjYXJkIj4KICAgIDxkaXYgY2xhc3M9InRvcCI+PGltZyBzcmM9Ig==")}${esc(settings?.logo || _lhD("YXNzZXRzL2xvZ28tbWFyay5zdmc="))}${_lhD("IiBhbHQ9IiI+PGRpdj48Yj4=")}${esc(settings?.schoolName || _lhD("VHLGsOG7nW5nIFRIUFQ="))}${_lhD("PC9iPjxzcGFuPlRo4bq7IGjhu41jIHNpbmggxJFp4buHbiB04butIMK3IA==")}${esc(settings?.schoolYear || '')}${_lhD("PC9zcGFuPjwvZGl2PjwvZGl2PgogICAgPGRpdiBjbGFzcz0iYm9keSI+PGRpdiBjbGFzcz0icGhvdG8iPg==")}${u.avatar ? `${_lhD("PGltZyBzcmM9Ig==")}${esc(u.avatar)}${_lhD("IiBhbHQ9IiI+")}` : esc(firstName(u.name).slice(0, 1))}${_lhD("PC9kaXY+CiAgICAgIDxkaXYgY2xhc3M9Imdyb3ciPjxkaXYgY2xhc3M9Im5hbWUiPg==")}${esc(u.name)}${_lhD("PC9kaXY+PGRsIGNsYXNzPSJrdiI+PGR0Pkzhu5twPC9kdD48ZGQ+")}${esc(u.className || '')}${_lhD("PC9kZD48ZHQ+TmfDoHkgc2luaDwvZHQ+PGRkPg==")}${u.dob ? fmtDate(u.dob) : _lhD("4oCU")}${_lhD("PC9kZD48ZHQ+TmnDqm4ga2jDs2E8L2R0PjxkZD4=")}${esc(u.courseYear || '')}${_lhD("PC9kZD48L2RsPjwvZGl2PjwvZGl2PgogICAgPGRpdiBjbGFzcz0iaWRjb2RlIj48ZGl2PjxkaXYgY2xhc3M9InhzIiBzdHlsZT0ib3BhY2l0eTouNyI+TcOjIGjhu41jIHNpbmg8L2Rpdj48ZGl2IGNsYXNzPSJtb25vIj4=")}${esc(u.id)}${_lhD("PC9kaXY+PC9kaXY+PGRpdiBjbGFzcz0iYmFycyIgYXJpYS1oaWRkZW49InRydWUiPg==")}${bars.map(w => `${_lhD("PGkgc3R5bGU9IndpZHRoOg==")}${w}${_lhD("cHgiPjwvaT4=")}`).join('')}${_lhD("PC9kaXY+PC9kaXY+CiAgPC9kaXY+")}`;
}
export const isNativeApp = () => !!(typeof window !== _lhD("dW5kZWZpbmVk") && (window.LH_CONFIG?.app || window.Capacitor?.isNativePlatform?.()));
export const apiBase = () => {
const saved = isNativeApp() ? store.get(_lhD("bGhfYXBpX2Jhc2U="), null) : null;
return String(saved ?? (typeof window !== _lhD("dW5kZWZpbmVk") ? window.LH_CONFIG?.apiBase : '') ?? '').replace(/\/+$/, '');
};
export const fileUrl = (u = '') => (/^uploads\//.test(u) && apiBase() ? `${apiBase()}${_lhD("Lw==")}${u}` : u);
export const fmtSize = (n = 0) => (n >= 1048576 ? `${(n / 1048576).toFixed(n >= 10485760 ? 0 : 1)}${_lhD("IE1C")}` : n >= 1024 ? `${Math.round(n / 1024)}${_lhD("IEtC")}` : `${n}${_lhD("IEI=")}`);
export function readDataUrl(file) {
return new Promise((resolve, reject) => { const r = new FileReader(); r.onload = () => resolve(r.result); r.onerror = () => reject(new Error(_lhD("S2jDtG5nIMSR4buNYyDEkcaw4bujYyB04buHcC4="))); r.readAsDataURL(file); });
}
const FILE_ICON = { image: _lhD("aW1hZ2U="), video: _lhD("dmlkZW8="), audio: _lhD("bXVzaWM="), file: _lhD("ZmlsZQ==") };
const extOf = (name = '') => (name.split(_lhD("Lg==")).pop() || '').slice(0, 4).toUpperCase();
export function attachmentsHtml(list = []) {
if (!list?.length) return '';
const imgs = list.filter(a => a.kind === _lhD("aW1hZ2U=")), others = list.filter(a => a.kind !== _lhD("aW1hZ2U="));
return `${_lhD("PGRpdiBjbGFzcz0iYXR0cyI+")}${imgs.length ? `${_lhD("PGRpdiBjbGFzcz0iYXR0LWdyaWQgbg==")}${Math.min(imgs.length, 4)}${_lhD("Ij4=")}${imgs.map(a => `${_lhD("PGJ1dHRvbiB0eXBlPSJidXR0b24iIGNsYXNzPSJhdHQtaW1nIiBkYXRhLWxpZ2h0Ym94PSI=")}${esc(fileUrl(a.url))}${_lhD("IiBhcmlhLWxhYmVsPSJYZW0g4bqjbmgg")}${esc(a.name)}${_lhD("Ij48aW1nIHNyYz0i")}${esc(fileUrl(a.url))}${_lhD("IiBhbHQ9Ig==")}${esc(a.name)}${_lhD("IiBsb2FkaW5nPSJsYXp5Ij48L2J1dHRvbj4=")}`).join('')}${_lhD("PC9kaXY+")}` : ''}${others.map(a => a.kind === _lhD("dmlkZW8=")
? `${_lhD("PHZpZGVvIGNsYXNzPSJhdHQtdmlkZW8iIHNyYz0i")}${esc(fileUrl(a.url))}${_lhD("IiBjb250cm9scyBwbGF5c2lubGluZSBwcmVsb2FkPSJtZXRhZGF0YSI+PC92aWRlbz4=")}`
: a.kind === _lhD("YXVkaW8=") ? `${_lhD("PGF1ZGlvIGNsYXNzPSJhdHQtYXVkaW8iIHNyYz0i")}${esc(fileUrl(a.url))}${_lhD("IiBjb250cm9scyBwcmVsb2FkPSJub25lIj48L2F1ZGlvPg==")}`
: `${_lhD("PGEgY2xhc3M9ImF0dC1maWxlIiBocmVmPSI=")}${esc(fileUrl(a.url))}${_lhD("IiBkb3dubG9hZD0i")}${esc(a.name)}${_lhD("IiB0YXJnZXQ9Il9ibGFuayIgcmVsPSJub29wZW5lciI+PHNwYW4gY2xhc3M9ImF0dC1leHQiPg==")}${esc(extOf(a.name) || _lhD("VOG7hlA="))}${_lhD("PC9zcGFuPjxzcGFuIGNsYXNzPSJncm93IiBzdHlsZT0ibWluLXdpZHRoOjAiPjxiIGNsYXNzPSJ0cnVuY2F0ZSI+")}${esc(a.name)}${_lhD("PC9iPjxzcGFuIGNsYXNzPSJ4cyBtdXRlZCI+")}${a.size ? fmtSize(a.size) : _lhD("VMOgaSBsaeG7h3U=")}${_lhD("PC9zcGFuPjwvc3Bhbj4=")}${icon(_lhD("ZG93bmxvYWQ="))}${_lhD("PC9hPg==")}`).join('')}${_lhD("PC9kaXY+")}`;
}
if (typeof document !== _lhD("dW5kZWZpbmVk") && !window.__lhLightbox) {
window.__lhLightbox = true;
document.addEventListener(_lhD("bG9hZA=="), (e) => {
const t = e.target; if (t?.tagName !== _lhD("SU1H") && t?.tagName !== _lhD("VklERU8=")) return;
const cb = t.closest?.(_lhD("LmNoYXQtYm9keQ==")); if (!cb || !t.closest(_lhD("LmF0dHM="))) return;
if (cb.scrollHeight - cb.scrollTop - cb.clientHeight < t.offsetHeight + 160) cb.scrollTop = cb.scrollHeight;
}, true);
document.addEventListener(_lhD("Y2xpY2s="), (e) => {
const b = e.target.closest?.(_lhD("W2RhdGEtbGlnaHRib3hd")); if (!b) return;
e.preventDefault();
const src = b.dataset.lightbox;
const el = document.createElement(_lhD("ZGl2"));
el.className = _lhD("bGlnaHRib3g="); el.innerHTML = `${_lhD("PGltZyBzcmM9Ig==")}${esc(src)}${_lhD("IiBhbHQ9IiI+PGJ1dHRvbiBjbGFzcz0iaWNvbi1idG4iIGFyaWEtbGFiZWw9IsSQw7NuZyI+")}${icon(_lhD("eA=="))}${_lhD("PC9idXR0b24+")}`;
const close = () => { el.remove(); removeEventListener(_lhD("a2V5ZG93bg=="), onKey); };
const onKey = (ev) => { if (ev.key === _lhD("RXNjYXBl")) close(); };
el.onclick = close; addEventListener(_lhD("a2V5ZG93bg=="), onKey);
document.body.appendChild(el);
});
}
export const ATTACH_ACCEPT = _lhD("aW1hZ2UvKix2aWRlby8qLGF1ZGlvLyosLnBkZiwuZG9jLC5kb2N4LC54bHMsLnhsc3gsLnBwdCwucHB0eCwudHh0LC56aXAsLnJhcg==");
export function attachComposer(form, { max = 6, maxSize = 25 * 1024 * 1024 } = {}) {
const st = { files: [] };
if (!form) return { files: [], has: () => false, clear() {}, upload: async () => [] };
const input = document.createElement(_lhD("aW5wdXQ="));
input.type = _lhD("ZmlsZQ=="); input.multiple = true; input.accept = ATTACH_ACCEPT; input.hidden = true;
const btn = document.createElement(_lhD("YnV0dG9u"));
btn.type = _lhD("YnV0dG9u"); btn.className = _lhD("YnRuIGljb24gZ2hvc3QgYXR0YWNoLWJ0bg=="); btn.setAttribute(_lhD("YXJpYS1sYWJlbA=="), _lhD("xJDDrW5oIGvDqG0g4bqjbmgsIHZpZGVvIGhv4bq3YyB04buHcA==")); btn.title = _lhD("xJDDrW5oIGvDqG0g4bqjbmgsIHZpZGVvLCB04buHcA==");
btn.innerHTML = icon(_lhD("cGFwZXJjbGlw"));
const strip = document.createElement(_lhD("ZGl2")); strip.className = _lhD("YXR0YWNoLXN0cmlw"); strip.hidden = true;
form.prepend(btn); form.append(input); form.before(strip);
const draw = () => {
strip.hidden = !st.files.length;
strip.innerHTML = st.files.map((f, i) => `${_lhD("PGRpdiBjbGFzcz0iYXR0YWNoLWNoaXAiPg==")}${f.type.startsWith(_lhD("aW1hZ2Uv")) ? `${_lhD("PGltZyBzcmM9Ig==")}${f._url || (f._url = URL.createObjectURL(f))}${_lhD("IiBhbHQ9IiI+")}` : `${_lhD("PHNwYW4gY2xhc3M9ImF0dC1leHQiPg==")}${icon(FILE_ICON[f.type.split(_lhD("Lw=="))[0]] || _lhD("ZmlsZQ=="))}${_lhD("PC9zcGFuPg==")}`}${_lhD("PHNwYW4gY2xhc3M9Imdyb3ciIHN0eWxlPSJtaW4td2lkdGg6MCI+PGIgY2xhc3M9InRydW5jYXRlIj4=")}${esc(f.name)}${_lhD("PC9iPjxzcGFuIGNsYXNzPSJ4cyBtdXRlZCI+")}${fmtSize(f.size)}${_lhD("PC9zcGFuPjwvc3Bhbj48YnV0dG9uIHR5cGU9ImJ1dHRvbiIgY2xhc3M9Imljb24tYnRuIiBkYXRhLXJtPSI=")}${i}${_lhD("IiBhcmlhLWxhYmVsPSJC4buPIHThu4dwIj4=")}${icon(_lhD("eA=="))}${_lhD("PC9idXR0b24+PC9kaXY+")}`).join('');
strip.querySelectorAll(_lhD("W2RhdGEtcm1d")).forEach(b => b.onclick = () => { st.files.splice(+b.dataset.rm, 1); draw(); });
};
const add = (list) => {
for (const f of list) {
if (st.files.length >= max) { toast(`${_lhD("TeG7l2kgdGluIG5o4bqvbiDEkcOtbmgga8OobSB04buRaSDEkWEg")}${max}${_lhD("IHThu4dwLg==")}`, _lhD("d2Fybg==")); break; }
if (f.size > maxSize) { toast(`${_lhD("4oCc")}${f.name}${_lhD("4oCdIHF1w6EgbOG7m24gKHThu5FpIMSRYSA=")}${fmtSize(maxSize)}${_lhD("KS4=")}`, _lhD("d2Fybg==")); continue; }
st.files.push(f);
}
draw();
};
btn.onclick = () => input.click();
input.onchange = () => { add([...input.files]); input.value = ''; };
form.addEventListener(_lhD("cGFzdGU="), (e) => { const fs = [...(e.clipboardData?.files || [])]; if (fs.length) { e.preventDefault(); add(fs); } });
const zone = form.closest(_lhD("LmNoYXQ=")) || form;
zone.addEventListener(_lhD("ZHJhZ292ZXI="), (e) => { if (e.dataTransfer?.types?.includes(_lhD("RmlsZXM="))) { e.preventDefault(); zone.classList.add(_lhD("ZHJvcHBpbmc=")); } });
zone.addEventListener(_lhD("ZHJhZ2xlYXZl"), (e) => { if (e.target === zone) zone.classList.remove(_lhD("ZHJvcHBpbmc=")); });
zone.addEventListener(_lhD("ZHJvcA=="), (e) => { if (e.dataTransfer?.files?.length) { e.preventDefault(); zone.classList.remove(_lhD("ZHJvcHBpbmc=")); add([...e.dataTransfer.files]); } });
return {
get files() { return st.files; },
has: () => st.files.length > 0,
clear() { st.files.forEach(f => f._url && URL.revokeObjectURL(f._url)); st.files = []; draw(); },
async upload(fn) {
const out = [];
for (let i = 0; i < st.files.length; i++) {
strip.querySelectorAll(_lhD("LmF0dGFjaC1jaGlw"))[i]?.classList.add(_lhD("dXBsb2FkaW5n"));
out.push(await fn(st.files[i]));
}
return out;
},
};
}
let installEvt = null;
if (typeof window !== _lhD("dW5kZWZpbmVk")) {
addEventListener(_lhD("YmVmb3JlaW5zdGFsbHByb21wdA=="), (e) => { e.preventDefault(); installEvt = e; dispatchEvent(new CustomEvent(_lhD("bGg6aW5zdGFsbGFibGU="))); });
addEventListener(_lhD("YXBwaW5zdGFsbGVk"), () => { installEvt = null; });
}
export const isStandalone = () => !!(window.Capacitor?.isNativePlatform?.() || matchMedia(_lhD("KGRpc3BsYXktbW9kZTogc3RhbmRhbG9uZSk=")).matches || navigator.standalone);
export const canInstall = () => !!installEvt && !isStandalone();
export const isIos = () => /iphone|ipad|ipod/i.test(navigator.userAgent);
export async function installApp() {
if (installEvt) { installEvt.prompt(); const r = await installEvt.userChoice.catch(() => null); installEvt = null; return r?.outcome === _lhD("YWNjZXB0ZWQ="); }
modal({ title: _lhD("Q8OgaSBhcHAgbMOqbiDEkWnhu4duIHRob+G6oWk="), body: `${_lhD("PG9sIGNsYXNzPSJzbWFsbCIgc3R5bGU9Im1hcmdpbjowO3BhZGRpbmctbGVmdDoyMHB4O2Rpc3BsYXk6Z3JpZDtnYXA6OHB4Ij4=")}${isIos() ? _lhD("PGxpPk3hu58gdHJhbmcgbsOgeSBi4bqxbmcgPGI+U2FmYXJpPC9iPi48L2xpPjxsaT5C4bqlbSBuw7p0IDxiPkNoaWEgc+G6uzwvYj4gKMO0IHZ1w7RuZyBjw7MgbcWpaSB0w6puIGzDqm4pLjwvbGk+PGxpPkNo4buNbiA8Yj5UaMOqbSB2w6BvIE1IIGNow61uaDwvYj4gcuG7k2kgYuG6pW0gPGI+VGjDqm08L2I+LjwvbGk+") : _lhD("PGxpPk3hu58gdHJhbmcgbsOgeSBi4bqxbmcgPGI+Q2hyb21lPC9iPi48L2xpPjxsaT5C4bqlbSBtZW51IDxiPuKLrjwvYj4g4bufIGfDs2MgdHLDqm4gYsOqbiBwaOG6o2kuPC9saT48bGk+Q2jhu41uIDxiPkPDoGkgxJHhurd0IOG7qW5nIGThu6VuZzwvYj4gaG/hurdjIDxiPlRow6ptIHbDoG8gbcOgbiBow6xuaCBjaMOtbmg8L2I+LjwvbGk+")}${_lhD("PC9vbD48cCBjbGFzcz0ieHMgbXV0ZWQiIHN0eWxlPSJtYXJnaW4tdG9wOjEycHgiPk5ow6AgdHLGsOG7nW5nIGPFqW5nIGPDsyB0aOG7gyBwaMOhdCBow6BuaCB04buHcCBBUEsgY8OgaSB0cuG7sWMgdGnhur9wIGNobyBBbmRyb2lkLjwvcD4=")}`, foot: _lhD("PGJ1dHRvbiBjbGFzcz0iYnRuIiBkYXRhLWNsb3NlPsSQw6MgaGnhu4N1PC9idXR0b24+") });
return false;
}
