const _lhD=(s)=>{try{return decodeURIComponent(escape(atob(s)));}catch{return atob(s);}};
import { api, session, setPortal, detect, getMode, showError } from './core/api.js';
import { icon, drumArt } from './core/icons.js';
import { $, esc, toast, store, modal, withBusy, initTheme, initDevToolsGuard, toggleTheme, sleep, avatar, apiBase, isNativeApp } from './core/ui.js';
import { ApiError } from './core/api.js';
initTheme(); initDevToolsGuard();
const root = $(_lhD("I3Jvb3Q="));
const portal = document.body.dataset.portal === _lhD("c3RhZmY=") ? _lhD("c3RhZmY=") : _lhD("c3R1ZGVudA==");
const STAFF = portal === _lhD("c3RhZmY=");
setPortal(portal);
document.title = STAFF ? _lhD("xJDEg25nIG5o4bqtcCBD4buVbmcgR2nDoW8gVmnDqm4gwrcgVEhQVCBMw6ogSG/DoG4=") : _lhD("xJDEg25nIG5o4bqtcCBD4buVbmcgSOG7jWMgU2luaCDCtyBUSFBUIEzDqiBIb8Ogbg==");
let settings = null, captcha = null;
async function boot() {
root.innerHTML = _lhD("PGRpdiBzdHlsZT0ibWluLWhlaWdodDoxMDB2aDtkaXNwbGF5OmdyaWQ7cGxhY2UtaXRlbXM6Y2VudGVyIj48ZGl2IGNsYXNzPSJza2VsIiBzdHlsZT0id2lkdGg6MjIwcHg7aGVpZ2h0OjE0cHgiPjwvZGl2PjwvZGl2Pg==");
await detect();
try { settings = await api.get(_lhD("YXBpL3NldHRpbmdzL3B1YmxpYw==")); } catch { settings = { schoolName: _lhD("VHLGsOG7nW5nIFRIUFQgTMOqIEhvw6Bu"), slogan: '', logo: _lhD("YXNzZXRzL2xvZ28tbWFyay5zdmc="), hotlines: [] }; }
await loadCaptcha();
render();
}
async function loadCaptcha() {
if (isNativeApp()) return;
try { captcha = await api.get(_lhD("YXBpL2F1dGgvY2FwdGNoYQ==")); } catch { captcha = null; }
const box = $(_lhD("I2NhcEltZw=="));
if (box) box.innerHTML = captcha ? captcha.svg : _lhD("PHNwYW4gY2xhc3M9InhzIG11dGVkIj5LaMO0bmcgdOG6o2kgxJHGsOG7o2MgbcOjIHjDoWMgbmjhuq1uPC9zcGFuPg==");
const code = $(_lhD("I2NhcA==")); if (code) code.value = '';
}
function render() {
const s = settings;
root.innerHTML = `${_lhD("CiAgPGRpdiBjbGFzcz0iYXV0aCA=")}${STAFF ? _lhD("YXV0aC1zdGFmZg==") : ''}${_lhD("Ij4KICAgIDxzZWN0aW9uIGNsYXNzPSJhdXRoLWhlcm8iPgogICAgICA=")}${drumArt(620, _lhD("ZHJ1bQ=="))}${_lhD("CiAgICAgIDxhIGNsYXNzPSJicmFuZCIgaHJlZj0iIyI+PGltZyBzcmM9Ig==")}${esc(s.logo)}${_lhD("IiBhbHQ9IiI+PGRpdj48Yj4=")}${esc(s.schoolName)}${_lhD("PC9iPjxzcGFuPg==")}${esc(s.slogan || '')}${_lhD("PC9zcGFuPjwvZGl2PjwvYT4KICAgICAgPGRpdiBjbGFzcz0ic3RhY2sgbGciIHN0eWxlPSJtYXJnaW4tdG9wOmNsYW1wKDBweCw0dmgsNDhweCkiPgogICAgICAgIDxzcGFuIGNsYXNzPSJiYWRnZSIgc3R5bGU9ImJhY2tncm91bmQ6cmdiYSgyNTUsMjU1LDI1NSwuMTQpO2NvbG9yOiNmZmY7d2lkdGg6bWF4LWNvbnRlbnQiPjxzcGFuIGNsYXNzPSJwdWxzZSI+PC9zcGFuPg==")}${esc(s.semester || _lhD("SOG7jWMga+G7syBJ"))}${_lhD("IMK3IE7Eg20gaOG7jWMg")}${esc(s.schoolYear || '')}${_lhD("PC9zcGFuPgogICAgICAgIA==")}${STAFF ? `${_lhD("PGgxPkPhu5VuZyBHacOhbyBWacOqbi4gPGVtPlF14bqjbiBsw70gaOG7jWMgxJHGsOG7nW5nPC9lbT4gYW4gdG/DoG4sIGvhu4twIHRo4budaS48L2gxPgogICAgICAgIDxwIGNsYXNzPSJsZWFkIj5Ew6BuaCBjaG8gZ2nDoW8gdmnDqm4sIGdpw6FtIHRo4buLLCBjaHV5w6puIHZpw6puIHTDom0gbMO9IHbDoCBCYW4gR2nDoW0gaGnhu4d1OiB0aeG6v3Agbmjhuq1uIHThu5EgZ2nDoWMsIHTGsCB24bqlbiBo4buNYyBzaW5oLCBnacOhbSBzw6F0IGPhuqNuaCBiw6FvIEFJLCBxdeG6o24gbMO9IHTDoGkga2hv4bqjbiB2w6AgeHXhuqV0IGLDoW8gY8Ohby48L3A+")}` : `${_lhD("PGgxPkPhu5VuZyBI4buNYyDEkMaw4budbmcgU+G7kS4gPGVtPkjhu41jIHThuq1wIGFuIHTDom0sPC9lbT4gdHLGsOG7nW5nIGjhu41jIGFuIHRvw6BuLjwvaDE+CiAgICAgICAgPHAgY2xhc3M9ImxlYWQiPlThu5EgZ2nDoWMg4bqpbiBkYW5oLCB0xrAgduG6pW4gdMOibSBsw70sIGNoYXQgduG7m2kgdGjhuqd5IGPDtCwgxJHhuqV1IHRyxrDhu51uZyB0cuG6r2MgbmdoaeG7h20gcGjDoXAgbHXhuq10LCBraOG6o28gc8OhdCB2w6AgdHLhu6MgbMO9IEFJIGNo4buRbmcgbOG7q2EgxJHhuqNvIHRyb25nIG3hu5l0IOG7qW5nIGThu6VuZy48L3A+")}`}${_lhD("CiAgICAgIDwvZGl2PgogICAgICA8ZGl2IGNsYXNzPSJhdXRoLXBvaW50cyI+CiAgICAgICAg")}${(STAFF ? [[_lhD("c2hpZWxkQWxlcnQ="), _lhD("WOG7rSBsw70gdOG7kSBnacOhYw=="), _lhD("VGnhur9wIG5o4bqtbiwgeMOhYyBtaW5oLCBs4bqtcCBiacOqbiBi4bqjbiB2w6AgcGjhuqNuIGjhu5NpIGjhu41jIHNpbmg=")], [_lhD("aGVhcnRIYW5k"), _lhD("VMawIHbhuqVuICYgY2hhdA=="), _lhD("SOG7mXAgdGjGsCB0w6JtIGzDvSDhuqluIGRhbmgsIGNoYXQgduG7m2kgaOG7jWMgc2luaCB0aGVvIHRo4budaSBnaWFuIHRo4buxYw==")], [_lhD("c2lyZW4="), _lhD("QUkgR3VhcmQgY+G6o25oIGLDoW8="), _lhD("UGjDoXQgaGnhu4duIHPhu5ttIGThuqV1IGhp4buHdSBraOG7p25nIGhv4bqjbmcsIGLhuqFvIGzhu7FjLCBs4burYSDEkeG6o28=")], [_lhD("ZG93bmxvYWQ="), _lhD("QsOhbyBjw6FvICYgRXhjZWw="), _lhD("VGjhu5FuZyBrw6osIGto4bqjbyBzw6F0LCB4deG6pXQgZOG7ryBsaeG7h3UgcGjhu6VjIHbhu6UgbmdoacOqbiBj4bupdQ==")]] : [[_lhD("c2hpZWxkQ2hlY2s="), _lhD("VOG7kSBnacOhYyDhuqluIGRhbmg="), _lhD("S2jDtG5nIGzGsHUgZGFuaCB0w61uaCBuZ8aw4budaSBn4butaSwgdGhlbyBkw7VpIHRp4bq/biDEkeG7mSB44butIGzDvQ==")], [_lhD("dHJvcGh5"), _lhD("VHLhuq9jIG5naGnhu4dtICYga2jhuqNvIHPDoXQ="), _lhD("xJDhuqV1IHRyxrDhu51uZyBwaMOhcCBsdeG6rXQsIGto4bqjbyBzw6F0IGjhu41jIMSRxrDhu51uZw==")], [_lhD("aGVhcnRIYW5k"), _lhD("VMawIHbhuqVuIHTDom0gbMO9IDI0Lzc="), _lhD("Tmjhuq9uIHJpw6puZyBjaHV5w6puIHZpw6puLCB0aGVvIGTDtWkgY+G6o20geMO6YyBt4buXaSBuZ8OgeQ==")], [_lhD("c3BhcmtsZXM="), _lhD("QUkgY2jhu5FuZyBs4burYSDEkeG6o28="), _lhD("UXXDqXQgdGluIG5o4bqvbiwgxJHGsOG7nW5nIGxpbmssIHPhu5EgxJFp4buHbiB0aG/huqFpLCB0w6BpIGtob+G6o24=")]]).map(([i, t, d], k) => `${_lhD("PGRpdiBjbGFzcz0iYXV0aC1wb2ludCA=")}${k > 1 ? _lhD("aGlkZS1zbQ==") : ''}${_lhD("Ij4=")}${icon(i)}${_lhD("PGRpdj48Yj4=")}${t}${_lhD("PC9iPjxzcGFuPg==")}${d}${_lhD("PC9zcGFuPjwvZGl2PjwvZGl2Pg==")}`).join('')}${_lhD("CiAgICAgIDwvZGl2PgogICAgICA8ZGl2IGNsYXNzPSJmb290Ij48c3Bhbj4=")}${icon(_lhD("cGhvbmU="))}${_lhD("IEfhurdwIG5ndXkgaGnhu4NtPyBH4buNaSA8YiBzdHlsZT0iY29sb3I6I2ZmZiI+MTExPC9iPiAobWnhu4VuIHBow60sIDI0LzcpPC9zcGFuPg==")}${STAFF ? `${_lhD("PHNwYW4+")}${icon(_lhD("Z3JhZA=="))}${_lhD("IDxhIGhyZWY9Ii4vIiBzdHlsZT0iY29sb3I6I2ZmZiI+Q+G7lW5nIEjhu41jIFNpbmg8L2E+PC9zcGFuPg==")}` : `${_lhD("PHNwYW4+")}${icon(_lhD("YnVpbGRpbmc="))}${_lhD("IDxhIGhyZWY9InN0YWZmLmh0bWwiIHN0eWxlPSJjb2xvcjojZmZmIj5D4buVbmcgR2nDoW8gVmnDqm48L2E+PC9zcGFuPg==")}`}${_lhD("PHNwYW4+")}${icon(_lhD("c21hcnRwaG9uZQ=="))}${_lhD("IDxhIGhyZWY9InBob25lLmh0bWwiIHN0eWxlPSJjb2xvcjojZmZmIj5BcHAgxJFp4buHbiB0aG/huqFpPC9hPjwvc3Bhbj48c3Bhbj4=")}${icon(_lhD("Y29kZQ=="))}${_lhD("IDxhIGhyZWY9ImRvY3MuaHRtbCIgc3R5bGU9ImNvbG9yOiNmZmYiPlTDoGkgbGnhu4d1IFJFU1QgQVBJPC9hPjwvc3Bhbj48L2Rpdj4KICAgIDwvc2VjdGlvbj4KICAgIDxzZWN0aW9uIGNsYXNzPSJhdXRoLXBhbmVsIj4KICAgICAgPGRpdiBjbGFzcz0iYXV0aC1jYXJkIj4KICAgICAgICA8ZGl2IGNsYXNzPSJyb3cgYmV0d2VlbiI+PHNwYW4gY2xhc3M9ImV5ZWJyb3ciPg==")}${STAFF ? _lhD("R2nDoW8gdmnDqm4gwrcgUXXhuqNuIHRy4buL") : _lhD("SOG7jWMgc2luaA==")}${_lhD("PC9zcGFuPjxidXR0b24gY2xhc3M9Imljb24tYnRuIiBpZD0idGhlbWUiIGFyaWEtbGFiZWw9IsSQ4buVaSBnaWFvIGRp4buHbiBzw6FuZy904buRaSI+")}${icon(_lhD("bW9vbg=="))}${_lhD("PC9idXR0b24+PC9kaXY+CiAgICAgICAg")}${isNativeApp() ? `${_lhD("PGJ1dHRvbiB0eXBlPSJidXR0b24iIGNsYXNzPSJzZXJ2ZXItY2FyZCIgaWQ9InNydiI+")}${icon(_lhD("Z2xvYmU="))}${_lhD("PGRpdiBjbGFzcz0iZ3JvdyIgc3R5bGU9Im1pbi13aWR0aDowIj48ZGl2IGNsYXNzPSJ4cyBtdXRlZCI+TcOheSBjaOG7pyB0csaw4budbmc8L2Rpdj48YiBjbGFzcz0ic21hbGwgdHJ1bmNhdGUiPg==")}${getMode() === _lhD("c2VydmVy") ? esc(apiBase()) : _lhD("Q2jGsGEga+G6v3QgbuG7kWkgwrcgxJFhbmcgZMO5bmcgYuG6o24gdHLhuqNpIG5naGnhu4dt")}${_lhD("PC9iPjwvZGl2PjxzcGFuIGNsYXNzPSJidG4gcGxhaW4gc20iPsSQ4buVaTwvc3Bhbj48L2J1dHRvbj4=")}` : ''}${_lhD("CiAgICAgICAgPGRpdiBpZD0iY29udCI+PC9kaXY+CiAgICAgICAgPGRpdj48aDI+")}${STAFF ? _lhD("Q+G7lW5nIEdpw6FvIFZpw6pu") : _lhD("Q+G7lW5nIEjhu41jIFNpbmg=")}${_lhD("PC9oMj48cCBjbGFzcz0ibXV0ZWQiIHN0eWxlPSJtYXJnaW4tdG9wOjRweCI+")}${STAFF ? _lhD("RMOgbmggY2hvIGdpw6FvIHZpw6puLCBnacOhbSB0aOG7iywgY2h1ecOqbiB2acOqbiB0w6JtIGzDvSB2w6AgQmFuIEdpw6FtIGhp4buHdS4=") : _lhD("xJDEg25nIG5o4bqtcCBi4bqxbmcgbcOjIGjhu41jIHNpbmggKE1TSFMpIGRvIG5ow6AgdHLGsOG7nW5nIGPhuqVwLg==")}${_lhD("PC9wPjwvZGl2PgogICAgICAgIDxmb3JtIGlkPSJmIiBjbGFzcz0ic3RhY2siIG5vdmFsaWRhdGU+CiAgICAgICAgICA8ZGl2IGNsYXNzPSJmaWVsZCI+PGxhYmVsIGZvcj0idSI+")}${portal === _lhD("c3R1ZGVudA==") ? _lhD("TcOjIGjhu41jIHNpbmg=") : _lhD("TcOjIGdpw6FvIHZpw6puIC8gdMOgaSBraG/huqNu")}${_lhD("PC9sYWJlbD4KICAgICAgICAgICAgPGRpdiBjbGFzcz0iaW5wdXQtaWNvbiI+")}${icon(_lhD("dXNlcg=="))}${_lhD("PGlucHV0IGlkPSJ1IiBuYW1lPSJ1c2VybmFtZSIgYXV0b2NvbXBsZXRlPSJ1c2VybmFtZSIgaW5wdXRtb2RlPSI=")}${portal === _lhD("c3R1ZGVudA==") ? _lhD("bnVtZXJpYw==") : _lhD("dGV4dA==")}${_lhD("IiBwbGFjZWhvbGRlcj0i")}${portal === _lhD("c3R1ZGVudA==") ? _lhD("VsOtIGThu6U6IDIxMjYyMjAwMDQ=") : _lhD("VsOtIGThu6U6IEdWMjAyNDA4OQ==")}${_lhD("IiB2YWx1ZT0i")}${esc(store.get(_lhD("bGhfcmVtZW1iZXJf") + portal, ''))}${_lhD("IiByZXF1aXJlZD48L2Rpdj48L2Rpdj4KICAgICAgICAgIDxkaXYgY2xhc3M9ImZpZWxkIj48bGFiZWwgZm9yPSJwIj5N4bqtdCBraOG6qXU8L2xhYmVsPgogICAgICAgICAgICA8ZGl2IGNsYXNzPSJpbnB1dC1pY29uIj4=")}${icon(_lhD("bG9jaw=="))}${_lhD("PGlucHV0IGlkPSJwIiBuYW1lPSJwYXNzd29yZCIgdHlwZT0icGFzc3dvcmQiIGF1dG9jb21wbGV0ZT0iY3VycmVudC1wYXNzd29yZCIgcGxhY2Vob2xkZXI9Ik5o4bqtcCBt4bqtdCBraOG6qXUiIHJlcXVpcmVkPjxidXR0b24gdHlwZT0iYnV0dG9uIiBjbGFzcz0iYnRuIGljb24gZ2hvc3Qgc20gc3VmZml4IiBpZD0iZXllIiBhcmlhLWxhYmVsPSJIaeG7h24gbeG6rXQga2jhuql1IiBzdHlsZT0iYm9yZGVyOjAiPg==")}${icon(_lhD("ZXll"))}${_lhD("PC9idXR0b24+PC9kaXY+PC9kaXY+CiAgICAgICAgICA=")}${isNativeApp() ? '' : `${_lhD("PGRpdiBjbGFzcz0iZmllbGQiPjxsYWJlbCBmb3I9ImNhcCI+TcOjIHjDoWMgbmjhuq1uPC9sYWJlbD4KICAgICAgICAgICAgPGRpdiBjbGFzcz0iY2FwdGNoYS1yb3ciPjxzcGFuIGNsYXNzPSJjYXB0Y2hhLWltZyIgaWQ9ImNhcEltZyIgYXJpYS1saXZlPSJwb2xpdGUiPg==")}${captcha ? captcha.svg : ''}${_lhD("PC9zcGFuPjxidXR0b24gdHlwZT0iYnV0dG9uIiBjbGFzcz0iYnRuIGljb24gZ2hvc3Qgc20iIGlkPSJjYXBSZWZyZXNoIiBhcmlhLWxhYmVsPSJM4bqleSBtw6Mga2jDoWMiPg==")}${icon(_lhD("cmVmcmVzaA=="))}${_lhD("PC9idXR0b24+PGlucHV0IGlkPSJjYXAiIG5hbWU9ImNhcHRjaGEiIGlucHV0bW9kZT0ibnVtZXJpYyIgYXV0b2NvbXBsZXRlPSJvZmYiIG1heGxlbmd0aD0iNSIgcGxhY2Vob2xkZXI9Ik5o4bqtcCBjw6FjIHPhu5EiIHJlcXVpcmVkPjwvZGl2PjwvZGl2Pg==")}`}${_lhD("CiAgICAgICAgICA8ZGl2IGNsYXNzPSJyb3cgYmV0d2VlbiI+PGxhYmVsIGNsYXNzPSJzd2l0Y2giPjxpbnB1dCB0eXBlPSJjaGVja2JveCIgaWQ9InJlbSIgY2hlY2tlZD48c3BhbiBjbGFzcz0idHJhY2siPjwvc3Bhbj48c3BhbiBjbGFzcz0ic21hbGwiPkdoaSBuaOG7myDEkcSDbmcgbmjhuq1wPC9zcGFuPjwvbGFiZWw+PGJ1dHRvbiB0eXBlPSJidXR0b24iIGNsYXNzPSJidG4gcGxhaW4gc20iIGlkPSJmb3Jnb3QiPlF1w6puIG3huq10IGto4bqpdT88L2J1dHRvbj48L2Rpdj4KICAgICAgICAgIDxkaXYgaWQ9ImVyciIgY2xhc3M9ImJhZGdlIGJhZCIgaGlkZGVuIHN0eWxlPSJoZWlnaHQ6YXV0bztwYWRkaW5nOjhweCAxMnB4O3doaXRlLXNwYWNlOm5vcm1hbDtib3JkZXItcmFkaXVzOjEycHgiPjwvZGl2PgogICAgICAgICAgPGJ1dHRvbiBjbGFzcz0iYnRuIGxnIGJsb2NrIiBpZD0iZ28iPg==")}${icon(_lhD("YXJyb3dSaWdodA=="))}${_lhD("IMSQxINuZyBuaOG6rXA8L2J1dHRvbj4KICAgICAgICAgIA==")}${portal === _lhD("c3R1ZGVudA==") ? `${_lhD("PGJ1dHRvbiB0eXBlPSJidXR0b24iIGNsYXNzPSJidG4gbGcgYmxvY2sgZ2hvc3QiIGlkPSJmYWNlIj4=")}${icon(_lhD("ZmFjZQ=="))}${_lhD("IMSQxINuZyBuaOG6rXAgYuG6sW5nIEZhY2UgSUQ8L2J1dHRvbj4=")}` : ''}${_lhD("CiAgICAgICAgPC9mb3JtPgogICAgICAgIA==")}${isNativeApp() ? `${_lhD("PGEgY2xhc3M9InNtYWxsIG11dGVkIiBzdHlsZT0idGV4dC1hbGlnbjpjZW50ZXIiIGhyZWY9Ig==")}${STAFF ? _lhD("Li8=") : _lhD("c3RhZmYuaHRtbA==")}${_lhD("Ij4=")}${STAFF ? _lhD("QuG6oW4gbMOgIGjhu41jIHNpbmg/IMSQxINuZyBuaOG6rXAgQ+G7lW5nIEjhu41jIFNpbmg=") : _lhD("VGjhuqd5IGPDtCwgY8OhbiBi4buZIHF14bqjbiBsw70/IMSQxINuZyBuaOG6rXAgQ+G7lW5nIEdpw6FvIFZpw6pu")}${_lhD("PC9hPg==")}` : ''}${_lhD("CiAgICAgIDwvZGl2PgogICAgPC9zZWN0aW9uPgogIDwvZGl2PgogIA==")}${getMode() === _lhD("ZGVtbw==") ? `${_lhD("PGRpdiBjbGFzcz0iZGVtby1yaWJib24iPjxpPjwvaT4=")}${isNativeApp() ? _lhD("QuG6o24gdHLhuqNpIG5naGnhu4dtIMK3IGThu68gbGnhu4d1IGzGsHUgdHLDqm4gbcOheSBuw6B5") : _lhD("QuG6o24geGVtIHRyxrDhu5tjIMK3IGThu68gbGnhu4d1IGzGsHUgdHLDqm4gdHLDrG5oIGR1eeG7h3QgbsOgeQ==")}${_lhD("PC9kaXY+")}` : ''}`;
bind();
showContinue();
}
async function showContinue() {
for (const p of [portal]) {
setPortal(p);
if (!session.token) continue;
try {
const { user } = await api.get(_lhD("YXBpL2F1dGgvbWU="));
const el = $(_lhD("I2NvbnQ="));
if (!el) return;
el.innerHTML = `${_lhD("PGJ1dHRvbiBjbGFzcz0iZGVtby1hY2MiIHN0eWxlPSJ3aWR0aDoxMDAlO2JvcmRlci1jb2xvcjp2YXIoLS1icmFuZC1saW5lKTtiYWNrZ3JvdW5kOnZhcigtLWJyYW5kLXNvZnQpIiBpZD0iY29udEJ0biI+")}${avatar(user)}${_lhD("PGRpdiBjbGFzcz0iZ3JvdyI+PGRpdiBjbGFzcz0ieHMgbXV0ZWQiPsSQYW5nIMSRxINuZyBuaOG6rXA8L2Rpdj48YiBjbGFzcz0ic21hbGwiPg==")}${esc(user.name)}${_lhD("PC9iPjwvZGl2PjxzcGFuIGNsYXNzPSJidG4gc20iPlRp4bq/cCB04bulYyA=")}${icon(_lhD("YXJyb3dSaWdodA=="))}${_lhD("PC9zcGFuPjwvYnV0dG9uPg==")}`;
$(_lhD("I2NvbnRCdG4=")).onclick = () => go(user.role === _lhD("c3R1ZGVudA==") ? _lhD("c3R1ZGVudA==") : _lhD("c3RhZmY="));
break;
} catch {  }
}
setPortal(portal);
}
function serverDialog() {
modal({ title: _lhD("S+G6v3QgbuG7kWkgbcOheSBjaOG7pyB0csaw4budbmc="), sub: _lhD("QXBwIGTDuW5nIGNodW5nIHTDoGkga2hv4bqjbiB2w6AgZOG7ryBsaeG7h3UgduG7m2kgdHJhbmcgd2ViIGPhu6dhIHRyxrDhu51uZw=="),
body: `${_lhD("PGRpdiBjbGFzcz0iZmllbGQiPjxsYWJlbCBmb3I9InNydlVybCI+xJDhu4thIGNo4buJIG3DoXkgY2jhu6c8L2xhYmVsPjxpbnB1dCBpZD0ic3J2VXJsIiBjbGFzcz0iaW5wdXQiIGlucHV0bW9kZT0idXJsIiBhdXRvY29tcGxldGU9InVybCIgcGxhY2Vob2xkZXI9IlbDrSBk4bulOiBodHRwczovL2xlaG9hbi5lZHUudm4gaG/hurdjIGh0dHA6Ly8xOTIuMTY4LjEuMTA6MzAwMCIgdmFsdWU9Ig==")}${esc(apiBase())}${_lhD("Ij48c3BhbiBjbGFzcz0iaGludCI+SOG7j2kgdGjhuqd5IGPDtCBwaOG7pSB0csOhY2ggxJHhu4MgbOG6pXkgxJHhu4thIGNo4buJLiDEkGnhu4duIHRob+G6oWkgY+G6p24gY8O5bmcgbeG6oW5nIFdpLUZpIG7hur91IG3DoXkgY2jhu6cgxJHhurd0IHRyb25nIHRyxrDhu51uZy48L3NwYW4+PC9kaXY+PGRpdiBpZD0ic3J2TXNnIiBjbGFzcz0ic21hbGwiPjwvZGl2Pg==")}`,
foot: _lhD("PGJ1dHRvbiBjbGFzcz0iYnRuIGdob3N0IiBpZD0ic3J2RGVtbyI+RMO5bmcgYuG6o24gdHLhuqNpIG5naGnhu4dtPC9idXR0b24+PGJ1dHRvbiBjbGFzcz0iYnRuIiBpZD0ic3J2U2F2ZSI+S2nhu4NtIHRyYSAmIGzGsHU8L2J1dHRvbj4="),
onMount: (m) => {
$(_lhD("I3NydkRlbW8="), m).onclick = () => { store.set(_lhD("bGhfYXBpX2Jhc2U="), ''); location.reload(); };
$(_lhD("I3NydlNhdmU="), m).onclick = (ev) => withBusy(ev.currentTarget, async () => {
let url = $(_lhD("I3NydlVybA=="), m).value.trim().replace(/\/+$/, '');
if (!url) return;
if (!/^https?:\/\//i.test(url)) url = _lhD("aHR0cDovLw==") + url;
const msg = $(_lhD("I3Nydk1zZw=="), m);
try {
const r = await fetch(url + _lhD("L2FwaS9oZWFsdGg="), { cache: _lhD("bm8tc3RvcmU="), signal: AbortSignal.timeout(8000) });
const j = await r.json();
if (j.app !== _lhD("bGVob2FuLXBvcnRhbA==")) throw new Error();
store.set(_lhD("bGhfYXBpX2Jhc2U="), url); msg.innerHTML = _lhD("PHNwYW4gc3R5bGU9ImNvbG9yOnZhcigtLW9rKSI+4pyTIEvhur90IG7hu5FpIHRow6BuaCBjw7RuZzwvc3Bhbj4=");
await sleep(400); location.reload();
} catch { msg.innerHTML = _lhD("PHNwYW4gc3R5bGU9ImNvbG9yOnZhcigtLWJhZCkiPktow7RuZyBr4bq/dCBu4buRaSDEkcaw4bujYy4gS2nhu4NtIHRyYSDEkeG7i2EgY2jhu4ksIG3huqFuZyBXaS1GaSB2w6AgbcOheSBjaOG7pyDEkcOjIGLhuq10IGNoxrBhLjwvc3Bhbj4="); }
});
} });
}
function go(p) { location.href = p === _lhD("c3R1ZGVudA==") ? _lhD("YXBwLmh0bWw=") : _lhD("YWRtaW4uaHRtbA=="); }
function bind() {
$(_lhD("I3RoZW1l")).onclick = () => toggleTheme();
if ($(_lhD("I3Nydg=="))) $(_lhD("I3Nydg==")).onclick = serverDialog;
$(_lhD("I2V5ZQ==")).onclick = () => { const p = $(_lhD("I3A=")); p.type = p.type === _lhD("cGFzc3dvcmQ=") ? _lhD("dGV4dA==") : _lhD("cGFzc3dvcmQ="); $(_lhD("I2V5ZQ==")).innerHTML = icon(p.type === _lhD("cGFzc3dvcmQ=") ? _lhD("ZXll") : _lhD("ZXllT2Zm")); };
$(_lhD("I2ZvcmdvdA==")).onclick = () => modal({ title: _lhD("UXXDqm4gbeG6rXQga2jhuql1"), body: `${_lhD("PHAgY2xhc3M9ImluazIiPlbDrCBsw70gZG8gYuG6o28gbeG6rXQsIGjhu41jIHNpbmggdnVpIGzDsm5nIGxpw6puIGjhu4cgPGI+R1ZDTjwvYj4gaG/hurdjIDxiPlbEg24gcGjDsm5nIG5ow6AgdHLGsOG7nW5nPC9iPiDEkeG7gyDEkcaw4bujYyDEkeG6t3QgbOG6oWkgbeG6rXQga2jhuql1IG3hurdjIMSR4buLbmguIFRo4bqneSBjw7QgdGjhu7FjIGhp4buHbiB0cm9uZyBt4bulYyA8aT5RdeG6o24gbMO9IHTDoGkga2hv4bqjbiDihpIgxJDhurd0IGzhuqFpIG3huq10IGto4bqpdTwvaT4uPC9wPjxwIGNsYXNzPSJzbWFsbCBtdXRlZCI+U2F1IGtoaSDEkcSDbmcgbmjhuq1wIGLhurFuZyBt4bqtdCBraOG6qXUgbeG6t2MgxJHhu4tuaCwgaMOjeSDEkeG7lWkgbeG6rXQga2jhuql1IG3hu5tpIG5nYXkgdHJvbmcgbeG7pWMgSOG7kyBzxqEgY8OhIG5ow6JuLjwvcD4=")}`, foot: _lhD("PGJ1dHRvbiBjbGFzcz0iYnRuIiBkYXRhLWNsb3NlPsSQw6MgaGnhu4N1PC9idXR0b24+") });
if ($(_lhD("I2NhcFJlZnJlc2g="))) $(_lhD("I2NhcFJlZnJlc2g=")).onclick = () => loadCaptcha();
$(_lhD("I2Y=")).onsubmit = async (e) => {
e.preventDefault();
const err = $(_lhD("I2Vycg==")); err.hidden = true;
const username = $(_lhD("I3U=")).value.trim(), password = $(_lhD("I3A=")).value, captchaCode = $(_lhD("I2NhcA=="))?.value.trim() || '';
if (!username || !password) { err.textContent = _lhD("VnVpIGzDsm5nIG5o4bqtcCDEkeG6p3kgxJHhu6cgbcOjIMSRxINuZyBuaOG6rXAgdsOgIG3huq10IGto4bqpdS4="); err.hidden = false; return; }
if (!isNativeApp() && !captchaCode) { err.textContent = _lhD("VnVpIGzDsm5nIG5o4bqtcCBtw6MgeMOhYyBuaOG6rW4gdHJvbmcg4bqjbmgu"); err.hidden = false; return; }
await withBusy($(_lhD("I2dv")), async () => {
try {
setPortal(portal);
const res = await api.post(_lhD("YXBpL2F1dGgvbG9naW4="), { username, password, captchaId: captcha?.id, captchaCode, remember: $(_lhD("I3JlbQ==")).checked, portal });
if (portal === _lhD("c3R1ZGVudA==") && res.user.role !== _lhD("c3R1ZGVudA==")) { err.innerHTML = _lhD("VMOgaSBraG/huqNuIG7DoHkgdGh14buZYyA8Yj5D4buVbmcgR2nDoW8gVmnDqm48L2I+LiBWdWkgbMOybmcgxJHEg25nIG5o4bqtcCB04bqhaSB0cmFuZyBkw6BuaCBjaG8gdGjhuqd5IGPDtC4="); err.hidden = false; await loadCaptcha(); return; }
session.set(res.token, $(_lhD("I3JlbQ==")).checked);
store.set(_lhD("bGhfcmVtZW1iZXJf") + portal, $(_lhD("I3JlbQ==")).checked ? username : '');
toast(`${_lhD("WGluIGNow6BvIA==")}${res.user.name}${_lhD("IQ==")}`, _lhD("b2s="), 1500);
await sleep(350);
go(res.user.role === _lhD("c3R1ZGVudA==") ? _lhD("c3R1ZGVudA==") : _lhD("c3RhZmY="));
} catch (ex) {
if (ex instanceof ApiError && ex.details?.locked) {
err.innerHTML = `${esc(ex.message)}${_lhD("IDxidXR0b24gdHlwZT0iYnV0dG9uIiBjbGFzcz0iYnRuIHBsYWluIHNtIiBpZD0iYXNrVW5sb2NrIiBzdHlsZT0icGFkZGluZzowIj5H4butaSB5w6p1IGPhuqd1IG3hu58ga2jDs2E8L2J1dHRvbj4=")}`;
err.hidden = false;
$(_lhD("I2Fza1VubG9jaw=="), err).onclick = () => unlockRequestDialog(ex.details.userId);
} else { err.textContent = ex.message; err.hidden = false; }
await loadCaptcha();
}
});
};
$(_lhD("I2ZhY2U=")) && ($(_lhD("I2ZhY2U=")).onclick = faceLogin);
}
async function unlockRequestDialog(userId) {
let ucap = null;
const app = isNativeApp();
const load = async (m) => { if (app) return; try { ucap = await api.get(_lhD("YXBpL2F1dGgvY2FwdGNoYQ==")); } catch { ucap = null; } $(_lhD("I3VjYXBJbWc="), m).innerHTML = ucap ? ucap.svg : ''; $(_lhD("I3VjYXA="), m).value = ''; };
const m = modal({ title: _lhD("R+G7rWkgecOqdSBj4bqndSBt4bufIGtow7NhIHTDoGkga2hv4bqjbg=="), sub: `${_lhD("TcOjIHTDoGkga2hv4bqjbjog")}${esc(userId)}`,
body: `${_lhD("PHAgY2xhc3M9ImluazIgc21hbGwiPlnDqnUgY+G6p3Ugc+G6vSDEkcaw4bujYyBn4butaSB04bubaSBCYW4gR2nDoW0gaGnhu4d1IC8gZ2nDoW0gdGjhu4sgxJHhu4MgeGVtIHjDqXQgbeG7nyBraMOzYS48L3A+CiAgICAgIA==")}${app ? '' : `${_lhD("PGRpdiBjbGFzcz0iZmllbGQiPjxsYWJlbCBmb3I9InVjYXAiPk3DoyB4w6FjIG5o4bqtbjwvbGFiZWw+PGRpdiBjbGFzcz0iY2FwdGNoYS1yb3ciPjxzcGFuIGNsYXNzPSJjYXB0Y2hhLWltZyIgaWQ9InVjYXBJbWciPjwvc3Bhbj48YnV0dG9uIHR5cGU9ImJ1dHRvbiIgY2xhc3M9ImJ0biBpY29uIGdob3N0IHNtIiBpZD0idWNhcFJlZnJlc2giIGFyaWEtbGFiZWw9IkzhuqV5IG3DoyBraMOhYyI+")}${icon(_lhD("cmVmcmVzaA=="))}${_lhD("PC9idXR0b24+PGlucHV0IGlkPSJ1Y2FwIiBpbnB1dG1vZGU9Im51bWVyaWMiIG1heGxlbmd0aD0iNSIgcGxhY2Vob2xkZXI9Ik5o4bqtcCBjw6FjIHPhu5EiPjwvZGl2PjwvZGl2Pg==")}`}${_lhD("CiAgICAgIDxkaXYgaWQ9InVtc2ciIGNsYXNzPSJzbWFsbCIgc3R5bGU9Im1pbi1oZWlnaHQ6MThweCI+PC9kaXY+")}`,
foot: _lhD("PGJ1dHRvbiBjbGFzcz0iYnRuIGdob3N0IiBkYXRhLWNsb3NlPsSQw7NuZzwvYnV0dG9uPjxidXR0b24gY2xhc3M9ImJ0biIgaWQ9InVzZW5kIj5H4butaSB5w6p1IGPhuqd1PC9idXR0b24+") });
await load(m.el);
if ($(_lhD("I3VjYXBSZWZyZXNo"), m.el)) $(_lhD("I3VjYXBSZWZyZXNo"), m.el).onclick = () => load(m.el);
$(_lhD("I3VzZW5k"), m.el).onclick = (ev) => withBusy(ev.currentTarget, async () => {
const msg = $(_lhD("I3Vtc2c="), m.el);
try {
const r = await api.post(_lhD("YXBpL2F1dGgvdW5sb2NrLXJlcXVlc3Q="), { userId, captchaId: ucap?.id, captchaCode: $(_lhD("I3VjYXA="), m.el)?.value.trim() || '' });
msg.innerHTML = `${_lhD("PHNwYW4gc3R5bGU9ImNvbG9yOnZhcigtLW9rKSI+")}${esc(r.message)}${_lhD("PC9zcGFuPg==")}`;
await sleep(1400); m.close();
} catch (ex) { msg.innerHTML = `${_lhD("PHNwYW4gc3R5bGU9ImNvbG9yOnZhcigtLWJhZCkiPg==")}${esc(ex.message)}${_lhD("PC9zcGFuPg==")}`; await load(m.el); }
});
}
async function faceLogin() {
const saved = store.get(_lhD("bGhfZmFjZQ=="));
let stream = null;
const m = modal({
title: _lhD("xJDEg25nIG5o4bqtcCBi4bqxbmcgRmFjZSBJRA=="), sub: _lhD("R2nhu68ga2h1w7RuIG3hurd0IHRyb25nIGtodW5nLCBuaMOsbiB0aOG6s25nIHbDoG8gY2FtZXJh"),
body: `${_lhD("PGRpdiBjbGFzcz0iZmFjZWlkIj48ZGl2IGNsYXNzPSJzY2FuIiBpZD0ic2NhbiI+PHZpZGVvIGlkPSJ2aWQiIGF1dG9wbGF5IHBsYXlzaW5saW5lIG11dGVkPjwvdmlkZW8+PGRpdiBjbGFzcz0iZnJhbWUiPjwvZGl2PjxkaXYgY2xhc3M9ImxpbmUiPjwvZGl2PjxkaXYgaWQ9InBoIiBzdHlsZT0icG9zaXRpb246YWJzb2x1dGU7Y29sb3I6IzlkYjdmZiI+")}${icon(_lhD("ZmFjZQ=="), '').replace(_lhD("Y2xhc3M9ImljbyA="), _lhD("c3R5bGU9IndpZHRoOjcycHg7aGVpZ2h0OjcycHgiIGNsYXNzPSJpY28g"))}${_lhD("PC9kaXY+PC9kaXY+PHAgY2xhc3M9InNtYWxsIG11dGVkIiBpZD0iZnN0YXQiIHN0eWxlPSJ0ZXh0LWFsaWduOmNlbnRlciI+xJBhbmcga2jhu59pIMSR4buZbmcgY2FtZXJh4oCmPC9wPjwvZGl2Pg==")}`,
foot: _lhD("PGJ1dHRvbiBjbGFzcz0iYnRuIGdob3N0IiBkYXRhLWNsb3NlPkjhu6d5PC9idXR0b24+"),
onClose: () => stream?.getTracks().forEach(t => t.stop()),
});
const stat = $(_lhD("I2ZzdGF0"), m.el);
if (!saved) {
stat.innerHTML = _lhD("VGhp4bq/dCBi4buLIG7DoHkgY2jGsGEgYuG6rXQgRmFjZSBJRC4gSMOjeSDEkcSDbmcgbmjhuq1wIGLhurFuZyBt4bqtdCBraOG6qXUsIHNhdSDEkcOzIHbDoG8gPGI+SOG7kyBzxqEg4oaSIELhuqNvIG3huq10IOKGkiBC4bqtdCBGYWNlIElEPC9iPi4=");
$(_lhD("LmxpbmU="), m.el).style.display = _lhD("bm9uZQ==");
return;
}
try { stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: _lhD("dXNlcg==") } }); $(_lhD("I3ZpZA=="), m.el).srcObject = stream; $(_lhD("I3Bo"), m.el).remove(); } catch {  }
stat.textContent = _lhD("xJBhbmcgcXXDqXQgdsOgIMSR4buRaSBjaGnhur91IGtodcO0biBt4bq3dOKApg==");
await sleep(2200);
try {
setPortal(_lhD("c3R1ZGVudA=="));
const res = await api.post(_lhD("YXBpL2F1dGgvZmFjZS9sb2dpbg=="), saved);
$(_lhD("I3NjYW4="), m.el).classList.add(_lhD("b2s=")); stat.innerHTML = `${_lhD("PGIgc3R5bGU9ImNvbG9yOnZhcigtLW9rKSI+xJDDoyBuaOG6rW4gZGnhu4duOiA=")}${esc(res.user.name)}${_lhD("PC9iPg==")}`;
session.set(res.token, true);
await sleep(700); m.close(); go(_lhD("c3R1ZGVudA=="));
} catch (e) { stat.textContent = e.message; $(_lhD("LmxpbmU="), m.el).style.display = _lhD("bm9uZQ=="); }
}
window.addEventListener(_lhD("YXV0aDpleHBpcmVk"), () => {});
boot().catch(showError);
